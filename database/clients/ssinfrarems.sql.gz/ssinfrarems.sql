-- MySQL dump 10.13  Distrib 5.6.41-84.1, for Linux (x86_64)
--
-- Host: localhost    Database: spite7n9_ssinfrarems
-- ------------------------------------------------------
-- Server version	5.6.41-84.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_advisor_docs`
--

DROP TABLE IF EXISTS `tb_advisor_docs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_advisor_docs` (
  `doc_id` bigint(18) NOT NULL AUTO_INCREMENT,
  `advisor_id` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `doc_name` text COLLATE latin1_general_ci NOT NULL,
  `doc` text COLLATE latin1_general_ci NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`doc_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_advisor_docs`
--

LOCK TABLES `tb_advisor_docs` WRITE;
/*!40000 ALTER TABLE `tb_advisor_docs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_advisor_docs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_activity`
--

DROP TABLE IF EXISTS `tbl_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_activity` (
  `activity_id` bigint(18) NOT NULL AUTO_INCREMENT,
  `activity` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`activity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_activity`
--

LOCK TABLES `tbl_activity` WRITE;
/*!40000 ALTER TABLE `tbl_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_admin_user`
--

DROP TABLE IF EXISTS `tbl_admin_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) COLLATE latin1_general_ci NOT NULL COMMENT 'this will be used ad user_name',
  `user_name` varchar(50) COLLATE latin1_general_ci NOT NULL COMMENT 'this will be used ad user_fill_name',
  `user_password` text COLLATE latin1_general_ci NOT NULL,
  `user_category` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `user_email_id` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `user_mobile` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `user_photo` text COLLATE latin1_general_ci NOT NULL,
  `user_status` int(1) NOT NULL,
  `user_created_by` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `user_created_by_ip` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `user_created_by_date` date NOT NULL,
  `user_created_by_time` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `user_last_access_date` date NOT NULL,
  `user_last_access_time` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `user_last_access_ip` varchar(25) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_admin_user`
--

LOCK TABLES `tbl_admin_user` WRITE;
/*!40000 ALTER TABLE `tbl_admin_user` DISABLE KEYS */;
INSERT INTO `tbl_admin_user` (`id`, `user_id`, `user_name`, `user_password`, `user_category`, `user_email_id`, `user_mobile`, `user_photo`, `user_status`, `user_created_by`, `user_created_by_ip`, `user_created_by_date`, `user_created_by_time`, `user_last_access_date`, `user_last_access_time`, `user_last_access_ip`) VALUES (1,'admin','admin','21232f297a57a5a743894a0e4a801fc3','admin','info@ssinfra.in','7611111124','20220418_103932sb.png',1,'admin','122.175.169.196','2022-04-18','10:39:32 AM','2022-06-25','06:01:14 PM','106.214.47.36');
/*!40000 ALTER TABLE `tbl_admin_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_admin_user_action`
--

DROP TABLE IF EXISTS `tbl_admin_user_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_user_action` (
  `action_id` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `action_on` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `action_user_category` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_user_name` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_user_date` date NOT NULL,
  `action_user_time` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_user_ip` varchar(30) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`action_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_admin_user_action`
--

LOCK TABLES `tbl_admin_user_action` WRITE;
/*!40000 ALTER TABLE `tbl_admin_user_action` DISABLE KEYS */;
INSERT INTO `tbl_admin_user_action` (`action_id`, `action_name`, `action_on`, `action_user_category`, `action_user_name`, `action_user_date`, `action_user_time`, `action_user_ip`) VALUES ('20220415192334DXOC173A0LQ','Login','','admin','admin','2022-04-15','07:23:34 PM','122.163.198.209'),('20220415192337KPSXD1F05I4','Log Out','','admin','admin','2022-04-15','07:23:37 PM','122.163.198.209'),('20220416134806FQ8ONG26VUD','Login','','admin','admin','2022-04-16','01:48:06 PM','106.214.38.199'),('20220418103816YISVBWZUOE6','Login','','admin','admin','2022-04-18','10:38:16 AM','122.175.169.196'),('202204181039325YIJN81FL96','USER PROFILE EDITED','USER ID : admin NAME : admin','admin','admin','2022-04-18','10:39:32 AM','122.175.169.196'),('20220418104303UXZ98M2IKV1','Login','','admin','admin','2022-04-18','10:43:03 AM','122.175.169.196'),('20220418104725EFJXUVWT6LZ','Login','','admin','admin','2022-04-18','10:47:25 AM','122.175.169.196'),('20220418112947DQNYZBSI016','Login','','admin','admin','2022-04-18','11:29:47 AM','122.175.169.196'),('20220418113034WLUFE54712N','NEW PROJECT CREATED','ID : 1, NAME : DEMO','admin','admin','2022-04-18','11:30:34 AM','122.175.169.196'),('20220418113104BMZ54VO17LH','Advisor LEVEL CREATED','ID : 1, TYPE : SS INFRA','admin','admin','2022-04-18','11:31:04 AM','122.175.169.196'),('2022041811313463YXQZMJFA4','Advisor LEVEL CREATED','ID : 2, TYPE : LEVEL-1','admin','admin','2022-04-18','11:31:34 AM','122.175.169.196'),('20220418113151HV6MFNZRLD4','PROPERTY ADDED','ON PROJECT : 1, NAME : DEMO, No Of Properties : 2','admin','admin','2022-04-18','11:31:51 AM','122.175.169.196'),('20220418113249W2V9ZKLGI6S','NEW Advisor REGISTERED','ID : 1, NAME : SS INFRA','admin','admin','2022-04-18','11:32:49 AM','122.175.169.196'),('20220418113334R5VT1C8X9GJ','NEW Advisor REGISTERED','ID : 2, NAME : MANISH','admin','admin','2022-04-18','11:33:34 AM','122.175.169.196'),('20220418113418N04GD1KZ2VJ','NEW CUSTOMER REGISTERED','ID : 1, NAME : demo','admin','admin','2022-04-18','11:34:18 AM','122.175.169.196'),('202204181134463Y1UWKVSOCR','PROPERTY BOOKED','ORDER NO ODR0001, AMOUNT : 250000','admin','admin','2022-04-18','11:34:46 AM','122.175.169.196'),('202204181135069UHCAMIBSPX','BOOKING APPROVED','ORDER NO : ODR0001','admin','admin','2022-04-18','11:35:06 AM','122.175.169.196'),('20220418113509PBN1ZK8JAHQ','BOOKING PAYMENT RECEIVE APPROVED','VOUCHER NO : 0001/DP/0001, ORDER NO :','admin','admin','2022-04-18','11:35:09 AM','122.175.169.196'),('202204181135238XF1DSPBQVG','PAYMENT RECEIVED','ORDER NO ODR0001, AMOUNT : 250000','admin','admin','2022-04-18','11:35:23 AM','122.175.169.196'),('20220418113541156ICPEQL0U','BOOKING PAYMENT RECEIVE REJECTED','VOUCHER NO : 0001/INS/0002, ORDER NO : 0001/INS/0002','admin','admin','2022-04-18','11:35:41 AM','122.175.169.196'),('202204181136012OVEX3RYS4M','PAYMENT RECEIVED','ORDER NO ODR0001, AMOUNT : 150000','admin','admin','2022-04-18','11:36:01 AM','122.175.169.196'),('2022041811360963GVH4KPYMD','BOOKING PAYMENT RECEIVE APPROVED','VOUCHER NO : 0001/INS/0003, ORDER NO :','admin','admin','2022-04-18','11:36:09 AM','122.175.169.196'),('20220418113755NZ3LVWT58HU','Advisor LEVEL CREATED','ID : 3, TYPE : LEVEL-2','admin','admin','2022-04-18','11:37:55 AM','122.175.169.196'),('202204181138134KAHOT823GL','Advisor PROMOTED','NAME : MANISH, from : LEVEL-1 to LEVEL-2','admin','admin','2022-04-18','11:38:13 AM','122.175.169.196'),('20220418113902U8K0FGQ1MHZ','PROPERTY BOOKED','ORDER NO ODR0002, AMOUNT : 300000','admin','admin','2022-04-18','11:39:02 AM','122.175.169.196'),('20220418113911TPRIMOS0UX7','BOOKING APPROVED','ORDER NO : ODR0002','admin','admin','2022-04-18','11:39:11 AM','122.175.169.196'),('202204181139142FIPKMEZCVW','BOOKING PAYMENT RECEIVE APPROVED','VOUCHER NO : 0002/DP/0004, ORDER NO :','admin','admin','2022-04-18','11:39:14 AM','122.175.169.196'),('20220418113930EGX4TU2J8IO','PAYMENT RECEIVED','ORDER NO ODR0002, AMOUNT : 200000','admin','admin','2022-04-18','11:39:30 AM','122.175.169.196'),('202204181139391MLSYON5KEV','BOOKING PAYMENT RECEIVE APPROVED','VOUCHER NO : 0002/INS/0005, ORDER NO :','admin','admin','2022-04-18','11:39:39 AM','122.175.169.196'),('20220418114331945LGEUNTXQ','PAYMENT RECEIVED','ORDER NO ODR0001, AMOUNT : 100000','admin','admin','2022-04-18','11:43:31 AM','122.175.169.196'),('202204181143407CRUNS8K409','BOOKING PAYMENT RECEIVE APPROVED','VOUCHER NO : 0001/INS/0006, ORDER NO :','admin','admin','2022-04-18','11:43:40 AM','122.175.169.196'),('20220418114508W036T4FZONJ','Advisor LEVEL CREATED','ID : 4, TYPE : LEVEL-3','admin','admin','2022-04-18','11:45:08 AM','122.175.169.196'),('20220418114524DVS7X5QNYWZ','Advisor PROMOTED','NAME : MANISH, from : LEVEL-2 to LEVEL-3','admin','admin','2022-04-18','11:45:24 AM','122.175.169.196'),('20220418114550NDV368WEJKR','PAYMENT RECEIVED','ORDER NO ODR0002, AMOUNT : 100000','admin','admin','2022-04-18','11:45:50 AM','122.175.169.196'),('20220418114602TYSJPIRWU3H','BOOKING PAYMENT RECEIVE APPROVED','VOUCHER NO : 0002/INS/0007, ORDER NO :','admin','admin','2022-04-18','11:46:02 AM','122.175.169.196'),('20220418114656GE02FHM7AY9','Advisor LEVEL DELETED','ID=2, LEVEL : LEVEL-1','admin','admin','2022-04-18','11:46:56 AM','122.175.169.196'),('20220418114702BGQDVLUE9PN','Advisor LEVEL DELETED','ID=3, LEVEL : LEVEL-2','admin','admin','2022-04-18','11:47:02 AM','122.175.169.196'),('202204181147066MVQAS8NC12','Advisor LEVEL DELETED','ID=4, LEVEL : LEVEL-3','admin','admin','2022-04-18','11:47:06 AM','122.175.169.196'),('202204181147138YTRD0LG679','Property DELETED','ID=2, NO : 02','admin','admin','2022-04-18','11:47:13 AM','122.175.169.196'),('20220418114718AVTSZ4WI0PJ','Property DELETED','ID=1, NO : 01','admin','admin','2022-04-18','11:47:18 AM','122.175.169.196'),('20220421123246L93WG75YXDA','Login','','admin','admin','2022-04-21','12:32:46 PM','182.70.216.209'),('20220421123402D2EWH7QZCJS','PROJECT EDITED','ID : 1, NAME : SS','admin','admin','2022-04-21','12:34:02 PM','182.70.216.209'),('20220421123628LQ97DYE3008','NEW PROJECT CREATED','ID : 2, NAME : SS VILAA DEMO','admin','admin','2022-04-21','12:36:28 PM','182.70.216.209'),('20220421123727RACKHP1S024','Advisor LEVEL EDITED','ID : 1, OLD : SS INFRA NEW : SS INFRA','admin','admin','2022-04-21','12:37:27 PM','182.70.216.209'),('202204211241091H93BSIX8ER','Advisor LEVEL CREATED','ID : 5, TYPE : TM','admin','admin','2022-04-21','12:41:09 PM','182.70.216.209'),('20220421124812PELONBYVC38','Log Out','','admin','admin','2022-04-21','12:48:12 PM','182.70.216.209'),('202204281134480JYN8UDC65Z','Login','','admin','admin','2022-04-28','11:34:48 AM','122.175.162.70'),('202204281135251GTN9PJBF6L','Log Out','','admin','admin','2022-04-28','11:35:25 AM','122.175.162.70'),('20220428161543Q30C9MOFYZ8','Login','','admin','admin','2022-04-28','04:15:43 PM','171.49.141.37'),('20220526232819OZH7LSQTNVI','Login','','admin','admin','2022-05-26','11:28:19 PM','110.224.187.20'),('20220527001049LD9HX64W5UA','Log Out','','admin','admin','2022-05-27','12:10:49 AM','110.224.187.20'),('20220527001253WY69AS521LI','Login','','admin','admin','2022-05-27','12:12:53 AM','110.224.187.20'),('202205270015498KA5FWMUI6C','Log Out','','admin','admin','2022-05-27','12:15:49 AM','110.224.187.20'),('20220618141320JAXVZ5S0P3Q','Login','','admin','admin','2022-06-18','02:13:20 PM','182.69.192.174'),('20220625171136FLK2GDE7U1R','Login','','admin','admin','2022-06-25','05:11:36 PM','106.214.47.36'),('20220625175444UECI7YBL3VQ','Login','','admin','admin','2022-06-25','05:54:44 PM','106.214.47.36'),('20220625180116480MONKDAF7','Log Out','','admin','admin','2022-06-25','06:01:16 PM','106.214.47.36');
/*!40000 ALTER TABLE `tbl_admin_user_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_advisor`
--

DROP TABLE IF EXISTS `tbl_advisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_advisor` (
  `advisor_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `advisor_code` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'ID NO',
  `advisor_password` text COLLATE latin1_general_ci NOT NULL,
  `advisor_sponsor` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Introducer Or Parent',
  `advisor_level_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `advisor_title` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `advisor_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `advisor_fname` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `advisor_sex` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `advisor_address` text COLLATE latin1_general_ci NOT NULL,
  `advisor_mobile` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `advisor_phone` varchar(12) COLLATE latin1_general_ci NOT NULL,
  `advisor_email` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `advisor_whatsapp_no` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `advisor_marital_status` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `advisor_bg` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `advisor_dob` date NOT NULL,
  `advisor_anniversary_date` date NOT NULL,
  `advisor_hire_date` date NOT NULL,
  `advisor_qualification` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `advisor_occupation` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `advisor_pan_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `advisor_photo` text COLLATE latin1_general_ci NOT NULL,
  `advisor_status` int(1) NOT NULL COMMENT 'iF aCTIVE THEN 1 ORHER WISE 0',
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  `last_access_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`advisor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_advisor`
--

LOCK TABLES `tbl_advisor` WRITE;
/*!40000 ALTER TABLE `tbl_advisor` DISABLE KEYS */;
INSERT INTO `tbl_advisor` (`advisor_id`, `advisor_code`, `advisor_password`, `advisor_sponsor`, `advisor_level_id`, `advisor_title`, `advisor_name`, `advisor_fname`, `advisor_sex`, `advisor_address`, `advisor_mobile`, `advisor_phone`, `advisor_email`, `advisor_whatsapp_no`, `advisor_marital_status`, `advisor_bg`, `advisor_dob`, `advisor_anniversary_date`, `advisor_hire_date`, `advisor_qualification`, `advisor_occupation`, `advisor_pan_no`, `advisor_photo`, `advisor_status`, `created_details`, `edited_details`, `last_access_details`) VALUES (1,'SS001','21232f297a57a5a743894a0e4a801fc3','','1','MR.','SS INFRA','..','MALE','..','9829729827','','ssinfra@gmail.com','','Unmarried','','1900-01-01','1900-01-01','2000-04-18','..','..','..','',1,'admin, admin, 2022-04-18, 11:32:49 AM, 122.175.169.196','admin, admin, 2022-04-18, 11:32:49 AM, 122.175.169.196',''),(2,'SS002','21232f297a57a5a743894a0e4a801fc3','1','4','MR.','MANISH','..','MALE','..','9770085144','','manish@gmail.com','','Unmarried','','1900-01-01','1900-01-01','2020-04-18','..','..','..','',1,'admin, admin, 2022-04-18, 11:33:34 AM, 122.175.169.196','admin, admin, 2022-04-18, 11:33:34 AM, 122.175.169.196','');
/*!40000 ALTER TABLE `tbl_advisor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_advisor_action`
--

DROP TABLE IF EXISTS `tbl_advisor_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_advisor_action` (
  `action_id` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `action_on` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `action_user_id` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_user_date` date NOT NULL,
  `action_user_time` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_user_ip` varchar(30) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`action_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_advisor_action`
--

LOCK TABLES `tbl_advisor_action` WRITE;
/*!40000 ALTER TABLE `tbl_advisor_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_advisor_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_advisor_commission`
--

DROP TABLE IF EXISTS `tbl_advisor_commission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_advisor_commission` (
  `commission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `commission_order_no` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Order No From Booking Table',
  `commission_voucher_no` varchar(50) COLLATE latin1_general_ci NOT NULL COMMENT 'Unique No From Booking Or Payment',
  `commission_project_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `commission_property_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `commission_property_type` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `commission_particular` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Toke, Down Payment Or Installment',
  `commission_date` date NOT NULL,
  `commission_voucher_date` date NOT NULL,
  `commission_customer_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `commission_advisor_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `commission_advisor_level_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'At The Time Of Booking Level Of Advisor According To which Commission Will Be Distributed',
  `commission_advisor_current_level_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'At The Time Of Commission Generation Level Of Getting Advisor',
  `commission_advisor_level_percent` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Level Percent at The Time Of Booking',
  `commission_advisor_level_diff_percent` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'According Which Commission Will Be Generated',
  `commission_amount` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Distributed Commission Of Advisor',
  `commission_tds_percent` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'TDS Percent From tbl_setting_tds',
  `commission_tds_amount` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'TDS Amount',
  `commission_nett_amount` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Commission After TDS Cut Off',
  `commission_voucher_amount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `commission_by_advisor_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Advisor Who Booked The Property',
  `commission_by` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Self Or Reference',
  `approved` tinyint(1) NOT NULL,
  PRIMARY KEY (`commission_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_advisor_commission`
--

LOCK TABLES `tbl_advisor_commission` WRITE;
/*!40000 ALTER TABLE `tbl_advisor_commission` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_advisor_commission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_advisor_dvr`
--

DROP TABLE IF EXISTS `tbl_advisor_dvr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_advisor_dvr` (
  `dvr_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `advisor_id` bigint(20) NOT NULL,
  `project_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `property_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `customer_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `mobile_no` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `occupation` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `city` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `address` text COLLATE latin1_general_ci NOT NULL,
  `response1` text COLLATE latin1_general_ci NOT NULL,
  `response2` text COLLATE latin1_general_ci NOT NULL,
  `response3` text COLLATE latin1_general_ci NOT NULL,
  `response4` text COLLATE latin1_general_ci NOT NULL,
  `response5` text COLLATE latin1_general_ci NOT NULL,
  `remarks` text COLLATE latin1_general_ci NOT NULL,
  `status` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `dvr_date` date NOT NULL,
  `remind_date` date NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`dvr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_advisor_dvr`
--

LOCK TABLES `tbl_advisor_dvr` WRITE;
/*!40000 ALTER TABLE `tbl_advisor_dvr` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_advisor_dvr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_advisor_payment`
--

DROP TABLE IF EXISTS `tbl_advisor_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_advisor_payment` (
  `payment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `payment_advisor_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `payment_amount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_bank` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_date` date NOT NULL,
  `payment_remark` text COLLATE latin1_general_ci NOT NULL,
  `approved` tinyint(1) NOT NULL COMMENT '0 for pending 1 for approved',
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_advisor_payment`
--

LOCK TABLES `tbl_advisor_payment` WRITE;
/*!40000 ALTER TABLE `tbl_advisor_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_advisor_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_advisor_promotion`
--

DROP TABLE IF EXISTS `tbl_advisor_promotion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_advisor_promotion` (
  `promotion_id` bigint(18) NOT NULL AUTO_INCREMENT,
  `advisor_id` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `prev_level_id` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `promoted_level_id` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `promotion_date` date NOT NULL,
  `promotion_time` time NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`promotion_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_advisor_promotion`
--

LOCK TABLES `tbl_advisor_promotion` WRITE;
/*!40000 ALTER TABLE `tbl_advisor_promotion` DISABLE KEYS */;
INSERT INTO `tbl_advisor_promotion` (`promotion_id`, `advisor_id`, `prev_level_id`, `promoted_level_id`, `promotion_date`, `promotion_time`, `created_details`, `edited_details`) VALUES (1,'2','2','3','2022-04-18','11:38:13','admin, admin, 2022-04-18, 11:38:13 AM, 122.175.169.196','admin, admin, 2022-04-18, 11:38:13 AM, 122.175.169.196'),(2,'2','3','4','2022-04-18','11:45:24','admin, admin, 2022-04-18, 11:45:24 AM, 122.175.169.196','admin, admin, 2022-04-18, 11:45:24 AM, 122.175.169.196');
/*!40000 ALTER TABLE `tbl_advisor_promotion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_award`
--

DROP TABLE IF EXISTS `tbl_award`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_award` (
  `award_id` bigint(18) NOT NULL AUTO_INCREMENT,
  `award` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`award_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_award`
--

LOCK TABLES `tbl_award` WRITE;
/*!40000 ALTER TABLE `tbl_award` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_award` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_complain`
--

DROP TABLE IF EXISTS `tbl_complain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_complain` (
  `complain_id` bigint(18) NOT NULL AUTO_INCREMENT,
  `complain` text COLLATE latin1_general_ci NOT NULL,
  `advisor_id` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `complain_from` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`complain_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_complain`
--

LOCK TABLES `tbl_complain` WRITE;
/*!40000 ALTER TABLE `tbl_complain` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_complain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_customer`
--

DROP TABLE IF EXISTS `tbl_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_customer` (
  `customer_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `customer_code` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `customer_password` text COLLATE latin1_general_ci NOT NULL,
  `customer_title` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `customer_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `customer_fname` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `customer_mobile` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `customer_phone` varchar(12) COLLATE latin1_general_ci NOT NULL,
  `customer_email` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `customer_whatsapp_no` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `customer_marital_status` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `customer_sex` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `customer_bg` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `customer_dob` date NOT NULL,
  `customer_anniversary_date` date NOT NULL,
  `customer_reg_date` date NOT NULL,
  `customer_pan` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `customer_address` text COLLATE latin1_general_ci NOT NULL,
  `customer_city` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `customer_photo` text COLLATE latin1_general_ci NOT NULL,
  `customer_occupation` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `customer_designation` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `customer_anual_income` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `customer_nominee_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `customer_nominee_dob` date NOT NULL,
  `customer_relation_with_nominee` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `customer_nominee_mobile` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `customer_nominee_phone` varchar(12) COLLATE latin1_general_ci NOT NULL,
  `customer_nominee_address` text COLLATE latin1_general_ci NOT NULL,
  `customer_status` tinyint(1) NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  `last_access_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_customer`
--

LOCK TABLES `tbl_customer` WRITE;
/*!40000 ALTER TABLE `tbl_customer` DISABLE KEYS */;
INSERT INTO `tbl_customer` (`customer_id`, `customer_code`, `customer_password`, `customer_title`, `customer_name`, `customer_fname`, `customer_mobile`, `customer_phone`, `customer_email`, `customer_whatsapp_no`, `customer_marital_status`, `customer_sex`, `customer_bg`, `customer_dob`, `customer_anniversary_date`, `customer_reg_date`, `customer_pan`, `customer_address`, `customer_city`, `customer_photo`, `customer_occupation`, `customer_designation`, `customer_anual_income`, `customer_nominee_name`, `customer_nominee_dob`, `customer_relation_with_nominee`, `customer_nominee_mobile`, `customer_nominee_phone`, `customer_nominee_address`, `customer_status`, `created_details`, `edited_details`, `last_access_details`) VALUES (1,'SSC001','7d2715fde13720eb153819a1961ded1e','MR.','demo','.','9898989898','','DEMO@GMAIL.COM','','Unmarried','MALE','','1900-01-01','1900-01-01','2020-04-18','..','..','..','','..','..','..','..','1900-01-01','..','8989898989','','..',1,'admin, admin, 2022-04-18, 11:34:18 AM, 122.175.169.196','admin, admin, 2022-04-18, 11:34:18 AM, 122.175.169.196','');
/*!40000 ALTER TABLE `tbl_customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_customer_action`
--

DROP TABLE IF EXISTS `tbl_customer_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_customer_action` (
  `action_id` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `action_on` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `action_user_id` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_user_date` date NOT NULL,
  `action_user_time` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_user_ip` varchar(30) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`action_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_customer_action`
--

LOCK TABLES `tbl_customer_action` WRITE;
/*!40000 ALTER TABLE `tbl_customer_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_customer_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_enquiry`
--

DROP TABLE IF EXISTS `tbl_enquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_enquiry` (
  `enquiry_id` bigint(18) NOT NULL AUTO_INCREMENT,
  `project_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `property_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `customer_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `mobile_no` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `occupation` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `city` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `address` text COLLATE latin1_general_ci NOT NULL,
  `response1` text COLLATE latin1_general_ci NOT NULL,
  `response2` text COLLATE latin1_general_ci NOT NULL,
  `response3` text COLLATE latin1_general_ci NOT NULL,
  `response4` text COLLATE latin1_general_ci NOT NULL,
  `response5` text COLLATE latin1_general_ci NOT NULL,
  `remarks` text COLLATE latin1_general_ci NOT NULL,
  `status` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `enquiry_date` date NOT NULL,
  `remind_date` date NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`enquiry_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_enquiry`
--

LOCK TABLES `tbl_enquiry` WRITE;
/*!40000 ALTER TABLE `tbl_enquiry` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_enquiry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_expense`
--

DROP TABLE IF EXISTS `tbl_expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_expense` (
  `expense_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `expense_category_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `expense_sub_category_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `expense_party` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `expense_credit_debit` varchar(10) COLLATE latin1_general_ci NOT NULL COMMENT 'Credit Or Debit',
  `expense_amount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `expense_date` date NOT NULL,
  `payment_mode` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `payment_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `payment_bank` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_date` date NOT NULL,
  `expense_note` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`expense_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_expense`
--

LOCK TABLES `tbl_expense` WRITE;
/*!40000 ALTER TABLE `tbl_expense` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_expense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_expense_category`
--

DROP TABLE IF EXISTS `tbl_expense_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_expense_category` (
  `category_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_expense_category`
--

LOCK TABLES `tbl_expense_category` WRITE;
/*!40000 ALTER TABLE `tbl_expense_category` DISABLE KEYS */;
INSERT INTO `tbl_expense_category` (`category_id`, `category_name`) VALUES (1,'BILL');
/*!40000 ALTER TABLE `tbl_expense_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_expense_sub_category`
--

DROP TABLE IF EXISTS `tbl_expense_sub_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_expense_sub_category` (
  `sub_category_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_expense_category',
  `sub_category_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`sub_category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_expense_sub_category`
--

LOCK TABLES `tbl_expense_sub_category` WRITE;
/*!40000 ALTER TABLE `tbl_expense_sub_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_expense_sub_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_project`
--

DROP TABLE IF EXISTS `tbl_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_project` (
  `project_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `project_address` text COLLATE latin1_general_ci NOT NULL,
  `project_photo` text COLLATE latin1_general_ci NOT NULL,
  `project_mouza` text COLLATE latin1_general_ci NOT NULL,
  `project_ph_no` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_1` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_2` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_3` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_4` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_5` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_6` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_amount_1` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_amount_2` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_amount_3` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_amount_4` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_amount_5` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_amount_6` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_project`
--

LOCK TABLES `tbl_project` WRITE;
/*!40000 ALTER TABLE `tbl_project` DISABLE KEYS */;
INSERT INTO `tbl_project` (`project_id`, `project_name`, `project_address`, `project_photo`, `project_mouza`, `project_ph_no`, `extra_charge_1`, `extra_charge_2`, `extra_charge_3`, `extra_charge_4`, `extra_charge_5`, `extra_charge_6`, `extra_charge_amount_1`, `extra_charge_amount_2`, `extra_charge_amount_3`, `extra_charge_amount_4`, `extra_charge_amount_5`, `extra_charge_amount_6`, `created_details`, `edited_details`) VALUES (1,'SS','..','','..','..','','','','','','','','','','','','','admin, admin, 2022-04-18, 11:30:34 AM, 122.175.169.196','admin, admin, 2022-04-21, 12:34:02 PM, 182.70.216.209'),(2,'SS VILAA DEMO','B','','...','.','','','','','','','','','','','','','admin, admin, 2022-04-21, 12:36:28 PM, 182.70.216.209','admin, admin, 2022-04-21, 12:36:28 PM, 182.70.216.209');
/*!40000 ALTER TABLE `tbl_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_project_details`
--

DROP TABLE IF EXISTS `tbl_project_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_project_details` (
  `project_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `project_property_type_id` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_setting_property_type',
  `project_standard_amount_percent` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `project_no_of_date_to_tokent_expiry` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'numeric or float'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_project_details`
--

LOCK TABLES `tbl_project_details` WRITE;
/*!40000 ALTER TABLE `tbl_project_details` DISABLE KEYS */;
INSERT INTO `tbl_project_details` (`project_id`, `project_property_type_id`, `project_standard_amount_percent`, `project_no_of_date_to_tokent_expiry`) VALUES ('1','1','100000','30'),('1','7','100000','30'),('2','1','100000','30'),('2','7','100000','30');
/*!40000 ALTER TABLE `tbl_project_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_project_property_type_rate`
--

DROP TABLE IF EXISTS `tbl_project_property_type_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_project_property_type_rate` (
  `project_id` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `property_type_id` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `plot_area_rate` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `built_up_area_rate` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `super_built_up_area_rate` varchar(18) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_project_property_type_rate`
--

LOCK TABLES `tbl_project_property_type_rate` WRITE;
/*!40000 ALTER TABLE `tbl_project_property_type_rate` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_project_property_type_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property`
--

DROP TABLE IF EXISTS `tbl_property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property` (
  `property_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `property_project_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary key of tbl_project',
  `property_type_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary key of tbl_setting_property_type',
  `property_no` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Display Name In Every Where',
  `property_status` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Available, Booked Or TempBooked',
  `property_plot_area` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Total Plot Area',
  `property_built_up_area` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'if Property Type not like Plots',
  `property_super_built_up_area` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'if Property Type not like Plots',
  `property_khasra_no` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `property_remarks` text COLLATE latin1_general_ci NOT NULL,
  `property_photo` text COLLATE latin1_general_ci NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`property_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property`
--

LOCK TABLES `tbl_property` WRITE;
/*!40000 ALTER TABLE `tbl_property` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property_booking`
--

DROP TABLE IF EXISTS `tbl_property_booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property_booking` (
  `booking_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_type` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Temporarily/Token or Permanent with Down Payment',
  `booking_commission_status` int(1) NOT NULL COMMENT 'If 1 then Comission Distributed if 0 then not distributed, kept for Next DP/INST',
  `booking_particular` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `booking_voucher_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `booking_date` date NOT NULL,
  `booking_token_exp_date` date NOT NULL COMMENT 'If Temporarily Booked By Token',
  `booking_project_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_project',
  `booking_property_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_property',
  `booking_order_no` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Booking Auto Number',
  `booking_customer_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_customer',
  `booking_executive_type` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Advisor Or Sales Executive',
  `booking_advisor_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_advisor',
  `booking_advisor_level` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Level Of Advisor at the time of booking',
  `booking_advisor_level_percent` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Level Percent  Of Booked By Advisor At The Time Of Booking',
  `booking_advisor_team` text COLLATE latin1_general_ci NOT NULL COMMENT 'Array of Sponsors Sepatated by , (At The Time Of Booking)',
  `booking_advisor_team_level` text COLLATE latin1_general_ci NOT NULL COMMENT 'Array of Sponsors Level Sepatated by ,(At The Time Of Booking)',
  `booking_advisor_team_level_percent` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Level Percent Of Advisor Sponsor''s Team At The Time Of Booking',
  `booking_advisor_team_level_percent_diff` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'According to this Commission Will Be Generated',
  `booking_property_plot_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_plot_area_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_built_up_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_built_up_area_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_super_built_up_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_super_built_up_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_plot_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_build_up_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_super_build_up_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discount_amount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discounted_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `fixed_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `govt_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `fixed_rate` tinyint(1) NOT NULL,
  `booking_remark` text COLLATE latin1_general_ci NOT NULL,
  `booking_cancel_status` varchar(10) COLLATE latin1_general_ci NOT NULL COMMENT 'Is Booking Canceled : Yes or NULL',
  `booking_cancel_details` text COLLATE latin1_general_ci NOT NULL COMMENT 'Details Of Cancelled If Canceled Done',
  `booking_payment_mode` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Bank Loan, Self ',
  `booking_payment_mode_bank` varchar(50) COLLATE latin1_general_ci NOT NULL COMMENT 'If Booking By Bank Loan',
  `booking_registry_status` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Registry Done Or Not (Yes, null)',
  `registry_doc` text COLLATE latin1_general_ci NOT NULL,
  `registry_receiver` text COLLATE latin1_general_ci NOT NULL,
  `registry_dispached` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `registry_dispached_by` text COLLATE latin1_general_ci NOT NULL,
  `registry_remarks` text COLLATE latin1_general_ci NOT NULL,
  `registry_date` date NOT NULL,
  `registry_dispached_date` date NOT NULL,
  `booking_mutation_status` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Is Mutation Done (Yes,Null)',
  `approved` tinyint(1) NOT NULL,
  `next_payment_date` date NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property_booking`
--

LOCK TABLES `tbl_property_booking` WRITE;
/*!40000 ALTER TABLE `tbl_property_booking` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property_booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property_booking_cancelled`
--

DROP TABLE IF EXISTS `tbl_property_booking_cancelled`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property_booking_cancelled` (
  `cancel_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_type` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Temporarily/Token or Permanent with Down Payment',
  `booking_commission_status` int(1) NOT NULL,
  `booking_particular` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `booking_voucher_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `booking_date` date NOT NULL,
  `booking_token_exp_date` date NOT NULL COMMENT 'If Temporarily Booked By Token',
  `booking_project_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_project',
  `booking_property_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_property',
  `booking_order_no` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Booking Auto Number',
  `booking_customer_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_customer',
  `booking_executive_type` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Advisor Or Sales Executive',
  `booking_advisor_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_advisor',
  `booking_advisor_level` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_advisor_level_percent` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_advisor_team_level_percent` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_advisor_team_level_percent_diff` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_advisor_team` text COLLATE latin1_general_ci NOT NULL COMMENT 'Array of Sponsors Sepatated by , (At The Time Of Booking)',
  `booking_advisor_team_level` text COLLATE latin1_general_ci NOT NULL COMMENT 'Array of Sponsors Level Sepatated by ,(At The Time Of Booking)',
  `booking_property_plot_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_plot_area_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_built_up_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_built_up_area_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_super_built_up_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_super_built_up_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_plot_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_build_up_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_super_build_up_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discount_amount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discounted_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `fixed_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `govt_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `fixed_rate` tinyint(1) NOT NULL,
  `booking_remark` text COLLATE latin1_general_ci NOT NULL,
  `booking_cancel_status` varchar(10) COLLATE latin1_general_ci NOT NULL COMMENT 'Is Booking Canceled : Yes or NULL',
  `booking_cancel_details` text COLLATE latin1_general_ci NOT NULL COMMENT 'Details Of Cancelled If Canceled Done',
  `booking_payment_mode` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Bank Loan, Self ',
  `booking_payment_mode_bank` varchar(50) COLLATE latin1_general_ci NOT NULL COMMENT 'If Booking By Bank Loan',
  `booking_registry_status` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Registry Done Or Not (Yes, null)',
  `registry_doc` text COLLATE latin1_general_ci NOT NULL,
  `registry_receiver` text COLLATE latin1_general_ci NOT NULL,
  `registry_dispached` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `registry_dispached_by` text COLLATE latin1_general_ci NOT NULL,
  `registry_remarks` text COLLATE latin1_general_ci NOT NULL,
  `registry_date` date NOT NULL,
  `registry_dispached_date` date NOT NULL,
  `booking_mutation_status` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Is Mutation Done (Yes,Null)',
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`cancel_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property_booking_cancelled`
--

LOCK TABLES `tbl_property_booking_cancelled` WRITE;
/*!40000 ALTER TABLE `tbl_property_booking_cancelled` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property_booking_cancelled` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property_booking_deleted`
--

DROP TABLE IF EXISTS `tbl_property_booking_deleted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property_booking_deleted` (
  `deleted_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_type` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Temporarily/Token or Permanent with Down Payment',
  `booking_commission_status` int(1) NOT NULL,
  `booking_particular` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `booking_voucher_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `booking_date` date NOT NULL,
  `booking_token_exp_date` date NOT NULL COMMENT 'If Temporarily Booked By Token',
  `booking_project_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_project',
  `booking_property_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_property',
  `booking_order_no` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Booking Auto Number',
  `booking_customer_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_customer',
  `booking_executive_type` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Advisor Or Sales Executive',
  `booking_advisor_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_advisor',
  `booking_advisor_level` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_advisor_level_percent` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_advisor_team` text COLLATE latin1_general_ci NOT NULL COMMENT 'Array of Sponsors Sepatated by , (At The Time Of Booking)',
  `booking_advisor_team_level` text COLLATE latin1_general_ci NOT NULL COMMENT 'Array of Sponsors Level Sepatated by ,(At The Time Of Booking)',
  `booking_advisor_team_level_percent` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_advisor_team_level_percent_diff` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_plot_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_plot_area_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_built_up_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_built_up_area_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_super_built_up_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_super_built_up_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_plot_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_build_up_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_super_build_up_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discount_amount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discounted_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `fixed_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `govt_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `fixed_rate` tinyint(1) NOT NULL,
  `booking_total_payment_received` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Sum of All Payment Received in this booking',
  `booking_remark` text COLLATE latin1_general_ci NOT NULL,
  `booking_cancel_status` varchar(10) COLLATE latin1_general_ci NOT NULL COMMENT 'Is Booking Canceled : Yes or NULL',
  `booking_cancel_details` text COLLATE latin1_general_ci NOT NULL COMMENT 'Details Of Cancelled If Canceled Done',
  `booking_payment_mode` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Bank Loan, Self ',
  `booking_payment_mode_bank` varchar(50) COLLATE latin1_general_ci NOT NULL COMMENT 'If Booking By Bank Loan',
  `booking_registry_status` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Registry Done Or Not (Yes, null)',
  `registry_doc` text COLLATE latin1_general_ci NOT NULL,
  `registry_receiver` text COLLATE latin1_general_ci NOT NULL,
  `registry_dispached` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `registry_dispached_by` text COLLATE latin1_general_ci NOT NULL,
  `registry_remarks` text COLLATE latin1_general_ci NOT NULL,
  `registry_date` date NOT NULL,
  `registry_dispached_date` date NOT NULL,
  `booking_mutation_status` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Is Mutation Done (Yes,Null)',
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  `deleted_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`deleted_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property_booking_deleted`
--

LOCK TABLES `tbl_property_booking_deleted` WRITE;
/*!40000 ALTER TABLE `tbl_property_booking_deleted` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property_booking_deleted` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property_booking_extra_charge`
--

DROP TABLE IF EXISTS `tbl_property_booking_extra_charge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property_booking_extra_charge` (
  `charge_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_id` bigint(20) NOT NULL,
  `charge_particular` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `charge_amount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `charge_paid` varchar(20) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`charge_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property_booking_extra_charge`
--

LOCK TABLES `tbl_property_booking_extra_charge` WRITE;
/*!40000 ALTER TABLE `tbl_property_booking_extra_charge` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property_booking_extra_charge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property_booking_extra_charge_payment`
--

DROP TABLE IF EXISTS `tbl_property_booking_extra_charge_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property_booking_extra_charge_payment` (
  `payment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `charge_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `voucher_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `payment_amount` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_no` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_bank` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_date` date NOT NULL,
  `payment_notes` text COLLATE latin1_general_ci NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property_booking_extra_charge_payment`
--

LOCK TABLES `tbl_property_booking_extra_charge_payment` WRITE;
/*!40000 ALTER TABLE `tbl_property_booking_extra_charge_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property_booking_extra_charge_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property_booking_payments`
--

DROP TABLE IF EXISTS `tbl_property_booking_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property_booking_payments` (
  `payment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `payment_booking_id` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `payment_order_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `payment_voucher_no` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `payment_heading` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `payment_project_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `payment_property_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `payment_customer_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `payment_installment_no` varchar(22) COLLATE latin1_general_ci NOT NULL,
  `payment_amount` varchar(22) COLLATE latin1_general_ci NOT NULL,
  `payment_date` date NOT NULL,
  `payment_booking_executive_type` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `payment_advisor_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `payment_mode` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'DD, Cheque, Fund Transffer, Cash etc',
  `payment_mode_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_bank` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_date` date NOT NULL,
  `payment_remarks` text COLLATE latin1_general_ci NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  `payment_first_payment` varchar(1) COLLATE latin1_general_ci NOT NULL COMMENT 'Payment During Booking (First Payment Or Not If First then 1 else null)',
  `approved` tinyint(1) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property_booking_payments`
--

LOCK TABLES `tbl_property_booking_payments` WRITE;
/*!40000 ALTER TABLE `tbl_property_booking_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property_booking_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property_booking_payments_doc`
--

DROP TABLE IF EXISTS `tbl_property_booking_payments_doc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property_booking_payments_doc` (
  `doc_id` bigint(18) NOT NULL AUTO_INCREMENT,
  `payment_id` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `doc_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `doc` text COLLATE latin1_general_ci NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`doc_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property_booking_payments_doc`
--

LOCK TABLES `tbl_property_booking_payments_doc` WRITE;
/*!40000 ALTER TABLE `tbl_property_booking_payments_doc` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property_booking_payments_doc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property_updates`
--

DROP TABLE IF EXISTS `tbl_property_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property_updates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `property_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `image` text NOT NULL,
  `remark` text NOT NULL,
  `created_details` text NOT NULL,
  `edited_details` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property_updates`
--

LOCK TABLES `tbl_property_updates` WRITE;
/*!40000 ALTER TABLE `tbl_property_updates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property_updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_setting_advisor_level`
--

DROP TABLE IF EXISTS `tbl_setting_advisor_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_setting_advisor_level` (
  `level_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `level_unit_sale` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `level_active_member` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `level_last_month` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `level_target` varchar(18) COLLATE latin1_general_ci NOT NULL COMMENT 'Taraget To Next Level',
  `created_details` text COLLATE latin1_general_ci NOT NULL COMMENT 'By Which User Created ',
  `edited_details` text COLLATE latin1_general_ci NOT NULL COMMENT 'By Which User Edited',
  PRIMARY KEY (`level_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_setting_advisor_level`
--

LOCK TABLES `tbl_setting_advisor_level` WRITE;
/*!40000 ALTER TABLE `tbl_setting_advisor_level` DISABLE KEYS */;
INSERT INTO `tbl_setting_advisor_level` (`level_id`, `level_name`, `level_unit_sale`, `level_active_member`, `level_last_month`, `level_target`, `created_details`, `edited_details`) VALUES (1,'SS INFRA','1000000000','10','','100000000000000000','admin, admin, 2022-04-21, 12:37:27 PM, 182.70.216.209','admin, admin, 2022-04-21, 12:37:27 PM, 182.70.216.209'),(5,'TM','10','1','','1000000','admin, admin, 2022-04-21, 12:41:09 PM, 182.70.216.209','admin, admin, 2022-04-21, 12:41:09 PM, 182.70.216.209');
/*!40000 ALTER TABLE `tbl_setting_advisor_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_setting_advisor_level_with_property_type`
--

DROP TABLE IF EXISTS `tbl_setting_advisor_level_with_property_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_setting_advisor_level_with_property_type` (
  `level_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `property_type_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `commission_percent` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `project_id` varchar(20) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_setting_advisor_level_with_property_type`
--

LOCK TABLES `tbl_setting_advisor_level_with_property_type` WRITE;
/*!40000 ALTER TABLE `tbl_setting_advisor_level_with_property_type` DISABLE KEYS */;
INSERT INTO `tbl_setting_advisor_level_with_property_type` (`level_id`, `property_type_id`, `commission_percent`, `project_id`) VALUES ('1','13','100','1'),('1','12','100','1'),('1','11','100','1'),('1','10','100','1'),('1','9','100','1'),('1','8','100','1'),('1','7','100','1'),('1','2','100','1'),('1','1','100','1'),('5','12','8','2'),('5','11','4','2'),('5','10','4','2'),('5','9','4','2'),('5','8','4','2'),('5','7','4','2'),('5','2','4','2'),('5','1','8','2'),('5','13','3','1'),('5','12','6','1'),('5','11','3','1'),('5','10','3','1'),('5','9','3','1'),('5','8','3','1'),('5','7','3','1'),('5','2','3','1'),('5','1','6','1'),('1','13','100','2'),('1','12','100','2'),('1','11','100','2'),('1','10','100','2'),('1','9','100','2'),('1','8','100','2'),('1','7','100','2'),('1','2','100','2'),('1','1','100','2'),('5','13','4','2');
/*!40000 ALTER TABLE `tbl_setting_advisor_level_with_property_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_setting_property_type`
--

DROP TABLE IF EXISTS `tbl_setting_property_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_setting_property_type` (
  `property_type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `property_type` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`property_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_setting_property_type`
--

LOCK TABLES `tbl_setting_property_type` WRITE;
/*!40000 ALTER TABLE `tbl_setting_property_type` DISABLE KEYS */;
INSERT INTO `tbl_setting_property_type` (`property_type_id`, `property_type`, `created_details`, `edited_details`) VALUES (1,'PLOTS','admin, admin, 2017-07-22, 04:12:27 PM, 47.247.8.175','admin, admin, 2017-07-22, 04:12:27 PM, 47.247.8.175'),(2,'FLAT','admin, admin, 2014-04-17, 11:03:41 AM, 122.168.189.38','admin, admin, 2014-04-17, 11:03:41 AM, 122.168.189.38'),(7,'HOUSE','admin, admin, 2016-09-18, 06:47:48 PM, 110.224.219.65','admin, admin, 2016-09-18, 06:47:48 PM, 110.224.219.65'),(8,'BANGLOW','admin, admin, 2020-01-02, 05:50:53 PM, 171.61.60.121','admin, admin, 2020-01-02, 05:50:53 PM, 171.61.60.121'),(9,'RO HOUSE','admin, admin, 2020-01-02, 05:51:13 PM, 171.61.60.121','admin, admin, 2020-01-02, 05:51:13 PM, 171.61.60.121'),(10,'SINGLEX HOUSE','admin, admin, 2020-01-02, 05:51:47 PM, 171.61.60.121','admin, admin, 2020-01-02, 05:51:47 PM, 171.61.60.121'),(11,'DUPLEX HOUSE','admin, admin, 2020-01-02, 05:52:17 PM, 171.61.60.121','admin, admin, 2020-01-02, 05:52:17 PM, 171.61.60.121'),(12,'FARM HOUSE','admin, admin, 2020-01-02, 05:52:41 PM, 171.61.60.121','admin, admin, 2020-01-02, 05:52:41 PM, 171.61.60.121'),(13,'SHOPS','admin, admin, 2020-02-27, 11:51:59 AM, 171.60.160.212','admin, admin, 2020-02-27, 11:51:59 AM, 171.60.160.212');
/*!40000 ALTER TABLE `tbl_setting_property_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_setting_tds`
--

DROP TABLE IF EXISTS `tbl_setting_tds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_setting_tds` (
  `tds` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_setting_tds`
--

LOCK TABLES `tbl_setting_tds` WRITE;
/*!40000 ALTER TABLE `tbl_setting_tds` DISABLE KEYS */;
INSERT INTO `tbl_setting_tds` (`tds`, `created_details`, `edited_details`) VALUES ('10','admin, admin, 2020-01-02, 11:50:04 AM, 171.61.60.121','admin, admin, 2020-01-02, 11:50:04 AM, 171.61.60.121');
/*!40000 ALTER TABLE `tbl_setting_tds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_site_settings`
--

DROP TABLE IF EXISTS `tbl_site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_site_settings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_name` text COLLATE latin1_general_ci NOT NULL COMMENT 'Used in Titel Tag',
  `site_heading` text COLLATE latin1_general_ci NOT NULL COMMENT 'Used In Header And Menu',
  `site_icon` text COLLATE latin1_general_ci NOT NULL COMMENT 'Used In Real Icon',
  `site_logo` text COLLATE latin1_general_ci NOT NULL COMMENT 'Used In Header As Heading Logo',
  `site_url_home` text COLLATE latin1_general_ci NOT NULL COMMENT 'Main Site Url',
  `site_application_url` text COLLATE latin1_general_ci NOT NULL COMMENT 'Application In Site Url',
  `site_company_name` text COLLATE latin1_general_ci NOT NULL COMMENT 'Full Name Of Company',
  `site_iso` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `site_copyright` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `advisor_title` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `id_prefix` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `email` text COLLATE latin1_general_ci NOT NULL,
  `phone` text COLLATE latin1_general_ci NOT NULL,
  `mobile` text COLLATE latin1_general_ci NOT NULL,
  `address` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_site_settings`
--

LOCK TABLES `tbl_site_settings` WRITE;
/*!40000 ALTER TABLE `tbl_site_settings` DISABLE KEYS */;
INSERT INTO `tbl_site_settings` (`id`, `site_name`, `site_heading`, `site_icon`, `site_logo`, `site_url_home`, `site_application_url`, `site_company_name`, `site_iso`, `site_copyright`, `advisor_title`, `id_prefix`, `email`, `phone`, `mobile`, `address`) VALUES (12,'S.S.INFRA','S.S.INFRA','','','www.ssinfracg.in','https://ssinfrarems.spitechcloud.in/Application/App/','S. S. INFRA','','','Advisor','SS',' info@ssinfracg.in','','+91-7611111124','F/s - 21, 1st Floor, C.L.C. Plaza, Mangla, Chowk, Bilaspur, (C.G.)');
/*!40000 ALTER TABLE `tbl_site_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_sms_sent`
--

DROP TABLE IF EXISTS `tbl_sms_sent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sms_sent` (
  `sms_id` int(10) NOT NULL AUTO_INCREMENT,
  `sms_birthday` date NOT NULL,
  `sms_anniversary` date NOT NULL,
  `sms_token_expiry_pre` date NOT NULL,
  `sms_token_expiry_current` date NOT NULL,
  `sms_token_expiry_after` date NOT NULL,
  PRIMARY KEY (`sms_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_sms_sent`
--

LOCK TABLES `tbl_sms_sent` WRITE;
/*!40000 ALTER TABLE `tbl_sms_sent` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_sms_sent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_spitech_sms_server`
--

DROP TABLE IF EXISTS `tbl_spitech_sms_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_spitech_sms_server` (
  `sms` tinyint(1) NOT NULL,
  `sms_url` text COLLATE latin1_general_ci NOT NULL,
  `mobile_parameter` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `message_parameter` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `mobile_prefix` varchar(5) COLLATE latin1_general_ci NOT NULL,
  `parameter1` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `value1` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `parameter2` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `value2` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `parameter3` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `value3` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `parameter4` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `value4` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `parameter5` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `value5` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `balance_url` text COLLATE latin1_general_ci NOT NULL,
  `bparameter1` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `bvalue1` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `bparameter2` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `bvalue2` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `bparameter3` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `bvalue3` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `bparameter4` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `bvalue4` varchar(25) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_spitech_sms_server`
--

LOCK TABLES `tbl_spitech_sms_server` WRITE;
/*!40000 ALTER TABLE `tbl_spitech_sms_server` DISABLE KEYS */;
INSERT INTO `tbl_spitech_sms_server` (`sms`, `sms_url`, `mobile_parameter`, `message_parameter`, `mobile_prefix`, `parameter1`, `value1`, `parameter2`, `value2`, `parameter3`, `value3`, `parameter4`, `value4`, `parameter5`, `value5`, `balance_url`, `bparameter1`, `bvalue1`, `bparameter2`, `bvalue2`, `bparameter3`, `bvalue3`, `bparameter4`, `bvalue4`) VALUES (1,'http://sendsms.spitechwebservices.com/api/sendmsg.php','phone','text','','user','SIDDHIBUILD','pass','SIDDHIBUILD','sender','SIDDHI','priority','ndnd','stype','normal','','','','','','','','','');
/*!40000 ALTER TABLE `tbl_spitech_sms_server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_spitech_user`
--

DROP TABLE IF EXISTS `tbl_spitech_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_spitech_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `user_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `user_password` text COLLATE latin1_general_ci NOT NULL,
  `user_email_id` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `user_mobile` varchar(10) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_spitech_user`
--

LOCK TABLES `tbl_spitech_user` WRITE;
/*!40000 ALTER TABLE `tbl_spitech_user` DISABLE KEYS */;
INSERT INTO `tbl_spitech_user` (`id`, `user_id`, `user_name`, `user_password`, `user_email_id`, `user_mobile`) VALUES (1,'admin','Spitech Pvt Ltd.','e6e061838856bf47e1de730719fb2609','admin@spitech.co.in','7828796979');
/*!40000 ALTER TABLE `tbl_spitech_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'spite7n9_ssinfrarems'
--

--
-- Dumping routines for database 'spite7n9_ssinfrarems'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-25 15:38:11
