-- MySQL dump 10.13  Distrib 5.6.41-84.1, for Linux (x86_64)
--
-- Host: localhost    Database: spite7n9_dctrealestate
-- ------------------------------------------------------
-- Server version	5.6.41-84.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_advisor_docs`
--

DROP TABLE IF EXISTS `tb_advisor_docs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_advisor_docs` (
  `doc_id` bigint(18) NOT NULL AUTO_INCREMENT,
  `advisor_id` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `doc_name` text COLLATE latin1_general_ci NOT NULL,
  `doc` text COLLATE latin1_general_ci NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`doc_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_advisor_docs`
--

LOCK TABLES `tb_advisor_docs` WRITE;
/*!40000 ALTER TABLE `tb_advisor_docs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_advisor_docs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_activity`
--

DROP TABLE IF EXISTS `tbl_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_activity` (
  `activity_id` bigint(18) NOT NULL AUTO_INCREMENT,
  `activity` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`activity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_activity`
--

LOCK TABLES `tbl_activity` WRITE;
/*!40000 ALTER TABLE `tbl_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_admin_user`
--

DROP TABLE IF EXISTS `tbl_admin_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) COLLATE latin1_general_ci NOT NULL COMMENT 'this will be used ad user_name',
  `user_name` varchar(50) COLLATE latin1_general_ci NOT NULL COMMENT 'this will be used ad user_fill_name',
  `user_password` text COLLATE latin1_general_ci NOT NULL,
  `user_category` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `user_email_id` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `user_mobile` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `user_photo` text COLLATE latin1_general_ci NOT NULL,
  `user_status` int(1) NOT NULL,
  `user_created_by` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `user_created_by_ip` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `user_created_by_date` date NOT NULL,
  `user_created_by_time` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `user_last_access_date` date NOT NULL,
  `user_last_access_time` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `user_last_access_ip` varchar(25) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_admin_user`
--

LOCK TABLES `tbl_admin_user` WRITE;
/*!40000 ALTER TABLE `tbl_admin_user` DISABLE KEYS */;
INSERT INTO `tbl_admin_user` (`id`, `user_id`, `user_name`, `user_password`, `user_category`, `user_email_id`, `user_mobile`, `user_photo`, `user_status`, `user_created_by`, `user_created_by_ip`, `user_created_by_date`, `user_created_by_time`, `user_last_access_date`, `user_last_access_time`, `user_last_access_ip`) VALUES (1,'admin','admin','21232f297a57a5a743894a0e4a801fc3','admin','info@spitech.in','8269424219','20150207_120348img4.jpg',1,'admin','192.168.1.4','2015-02-07','04:34:05 PM','2022-06-25','04:17:24 PM','59.88.58.70');
/*!40000 ALTER TABLE `tbl_admin_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_admin_user_action`
--

DROP TABLE IF EXISTS `tbl_admin_user_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_user_action` (
  `action_id` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `action_on` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `action_user_category` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_user_name` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_user_date` date NOT NULL,
  `action_user_time` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_user_ip` varchar(30) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`action_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_admin_user_action`
--

LOCK TABLES `tbl_admin_user_action` WRITE;
/*!40000 ALTER TABLE `tbl_admin_user_action` DISABLE KEYS */;
INSERT INTO `tbl_admin_user_action` (`action_id`, `action_name`, `action_on`, `action_user_category`, `action_user_name`, `action_user_date`, `action_user_time`, `action_user_ip`) VALUES ('202112240133375WVMEXZGCFO','Login','','admin','admin','2021-12-24','01:33:37 AM','122.163.194.86'),('20211224013340KVODH3E970S','Log Out','','admin','admin','2021-12-24','01:33:40 AM','122.163.194.86'),('20211224104434JR5PWAFBGHE','Login','','admin','admin','2021-12-24','10:44:34 AM','182.69.89.228'),('20211224104513LX06A9YTI5W','Log Out','','admin','admin','2021-12-24','10:45:13 AM','182.69.89.228'),('20211230165415BTLRINJUKSZ','Login','','admin','admin','2021-12-30','04:54:15 PM','122.175.140.84'),('20211231110908C9VURI2METZ','Login','','admin','admin','2021-12-31','11:09:08 AM','122.175.171.134'),('20211231111420FO5PA27C8NH','NEW PROJECT CREATED','ID : 1, NAME : DWARKAPURAM','admin','admin','2021-12-31','11:14:20 AM','122.175.171.134'),('20211231111450XBS8ZYLK7HT','NEW PROJECT CREATED','ID : 2, NAME : GOLDAN PARK','admin','admin','2021-12-31','11:14:50 AM','122.175.171.134'),('20211231111524DERVQO6GBH7','Advisor LEVEL CREATED','ID : 1, TYPE : COMPANY','admin','admin','2021-12-31','11:15:24 AM','122.175.171.134'),('20211231111624O6RDSZF3BC8','NEW Advisor REGISTERED','ID : 1, NAME : DCT REAL ESTATE','admin','admin','2021-12-31','11:16:24 AM','122.175.171.134'),('20211231113234OMTRHZIQJ8W','Log Out','','admin','admin','2021-12-31','11:32:34 AM','122.175.171.134'),('20211231113254G4JDBV0NR7L','Login','','admin','admin','2021-12-31','11:32:54 AM','122.175.171.134'),('2021123111331948ULKVFIC9H','Log Out','','admin','admin','2021-12-31','11:33:19 AM','122.175.171.134'),('20211231120625YCFNI6H5XGZ','Login','','admin','admin','2021-12-31','12:06:25 PM','122.175.171.134'),('20211231122950LYFBO94WPZT','Login','','admin','admin','2021-12-31','12:29:50 PM','110.224.175.240'),('20220104161240WJ2G7OCTBQN','Login','','admin','admin','2022-01-04','04:12:40 PM','110.224.175.42'),('20220104161520FAJTZ16POH4','NEW PROJECT CREATED','ID : 3, NAME : INDU IMPERIA','admin','admin','2022-01-04','04:15:20 PM','110.224.175.42'),('20220104161950X2UAPVW48H7','Advisor LEVEL EDITED','ID : 1, OLD : COMPANY NEW : COMPANY','admin','admin','2022-01-04','04:19:50 PM','110.224.175.42'),('20220104162308O3IN48HY5UM','Advisor LEVEL CREATED','ID : 2, TYPE : LEVEL-1','admin','admin','2022-01-04','04:23:08 PM','110.224.175.42'),('20220104162358YXU13E2KJ7T','Advisor LEVEL CREATED','ID : 3, TYPE : LEVEL-2','admin','admin','2022-01-04','04:23:58 PM','110.224.175.42'),('20220104162539Q90C14B3XHM','Advisor LEVEL CREATED','ID : 4, TYPE : LEVEL-3','admin','admin','2022-01-04','04:25:39 PM','110.224.175.42'),('20220104162604YXE1GF95TI3','PROPERTY TYPE DELETED','ID=10, PROPERTY TYPE : SINGLEX HOUSE','admin','admin','2022-01-04','04:26:04 PM','110.224.175.42'),('20220104162610RM0OX3VGFN8','PROPERTY TYPE DELETED','ID=11, PROPERTY TYPE : DUPLEX HOUSE','admin','admin','2022-01-04','04:26:10 PM','110.224.175.42'),('2022010416261500NQ13ZLH7C','PROPERTY TYPE DELETED','ID=9, PROPERTY TYPE : RO HOUSE','admin','admin','2022-01-04','04:26:15 PM','110.224.175.42'),('20220104163003WI5JT80BXNK','PROJECT EDITED','ID : 1, NAME : DWARKAPURAM BLOCKA','admin','admin','2022-01-04','04:30:03 PM','110.224.175.42'),('202201041632028CNTHM7E91A','NEW PROJECT CREATED','ID : 4, NAME : DWARKAPURAM BLOCKB','admin','admin','2022-01-04','04:32:02 PM','110.224.175.42'),('202201041632355QRFOJ2DACN','NEW PROJECT CREATED','ID : 5, NAME : DWARKAPURAM BLOCKC','admin','admin','2022-01-04','04:32:35 PM','110.224.175.42'),('20220104163308E4WMPCYKZL7','NEW PROJECT CREATED','ID : 6, NAME : DWARKAPURAM LIG','admin','admin','2022-01-04','04:33:08 PM','110.224.175.42'),('20220104163818G0FW3ON6Z82','PROPERTY ADDED','ON PROJECT : 1, NAME : DWARKAPURAM BLOCKA, No Of Properties : 10','admin','admin','2022-01-04','04:38:18 PM','110.224.175.42'),('20220104163855STMHZJ3QB0W','Log Out','','admin','admin','2022-01-04','04:38:55 PM','110.224.175.42'),('20220104163907HIYGOL18MV0','Login','','admin','admin','2022-01-04','04:39:07 PM','110.224.175.42'),('20220104164437LZEPHUVQAYF','PROJECT DELETED','ID=1, NAME : DWARKAPURAM BLOCKA','admin','admin','2022-01-04','04:44:37 PM','110.224.175.42'),('20220104164443VZ17OTWRHLM','PROJECT DELETED','ID=4, NAME : DWARKAPURAM BLOCKB','admin','admin','2022-01-04','04:44:43 PM','110.224.175.42'),('20220104164448W8UD24Y7PAR','PROJECT DELETED','ID=5, NAME : DWARKAPURAM BLOCKC','admin','admin','2022-01-04','04:44:48 PM','110.224.175.42'),('20220104164458A017PZJRMGT','PROJECT DELETED','ID=6, NAME : DWARKAPURAM LIG','admin','admin','2022-01-04','04:44:58 PM','110.224.175.42'),('202201041648025G9XVD2EJI8','PROJECT EDITED','ID : 2, NAME : GOLDAN PARK CHHATAUNA','admin','admin','2022-01-04','04:48:02 PM','110.224.175.42'),('20220104164848WP57IDVX6FT','NEW PROJECT CREATED','ID : 7, NAME : GOLDEN PARK BODRI','admin','admin','2022-01-04','04:48:48 PM','110.224.175.42'),('20220104165249ND2GSACPMJK','PROPERTY ADDED','ON PROJECT : 7, NAME : GOLDEN PARK BODRI, No Of Properties : 10','admin','admin','2022-01-04','04:52:49 PM','110.224.175.42'),('20220104165949KEOG5A6HTSD','PROPERTY ADDED','ON PROJECT : 7, NAME : GOLDEN PARK BODRI, No Of Properties : 10','admin','admin','2022-01-04','04:59:49 PM','110.224.175.42'),('20220104171639HD4RBIVUYTX','NEW CUSTOMER REGISTERED','ID : 1, NAME : Alok Kumar Dubey','admin','admin','2022-01-04','05:16:39 PM','110.224.175.42'),('202201041717524RUWY1MHF8X','PROPERTY BOOKED','ORDER NO ODR0001, AMOUNT : 2000000','admin','admin','2022-01-04','05:17:52 PM','110.224.175.42'),('20220104171809A9O4IKFZVES','BOOKING APPROVED','ORDER NO : ODR0001','admin','admin','2022-01-04','05:18:09 PM','110.224.175.42'),('20220104171813LAZUPSV87DJ','BOOKING PAYMENT RECEIVE APPROVED','VOUCHER NO : 0001/DP/0001, ORDER NO :','admin','admin','2022-01-04','05:18:13 PM','110.224.175.42'),('20220105113741D5IKSURYE60','Login','','admin','admin','2022-01-05','11:37:41 AM','182.69.93.95'),('2022010612581329QME0K5W7Z','Login','','admin','admin','2022-01-06','12:58:13 PM','49.35.135.72'),('20220106130214G42YH8R75CA','PROPERTY ADDED','ON PROJECT : 2, NAME : GOLDAN PARK CHHATAUNA, No Of Properties : 10','admin','admin','2022-01-06','01:02:14 PM','49.35.135.72'),('202201061307008YUIMK24WL5','PROPERTY ADDED','ON PROJECT : 2, NAME : GOLDAN PARK CHHATAUNA, No Of Properties : 10','admin','admin','2022-01-06','01:07:00 PM','49.35.135.72'),('202201061311401YTE3HM8KS6','PROPERTY ADDED','ON PROJECT : 2, NAME : GOLDAN PARK CHHATAUNA, No Of Properties : 10','admin','admin','2022-01-06','01:11:40 PM','49.35.135.72'),('20220106131930IJGD2AKQVUC','PROPERTY ADDED','ON PROJECT : 2, NAME : GOLDAN PARK CHHATAUNA, No Of Properties : 11','admin','admin','2022-01-06','01:19:30 PM','49.35.135.72'),('202201061322161GCZK83RU25','PROPERTY ADDED','ON PROJECT : 2, NAME : GOLDAN PARK CHHATAUNA, No Of Properties : 3','admin','admin','2022-01-06','01:22:16 PM','49.35.135.72'),('202201061336319R2CN750G3K','Login','','admin','admin','2022-01-06','01:36:31 PM','182.69.207.178'),('20220106173912IEQ3SZ7URA1','Login','','admin','admin','2022-01-06','05:39:12 PM','182.69.207.178'),('20220107141304ECSP593XHJD','Login','','admin','admin','2022-01-07','02:13:04 PM','49.35.156.36'),('202201071708190U4JIWY6CGH','Login','','admin','admin','2022-01-07','05:08:19 PM','49.35.137.11'),('202201071708218UPKJEZBOV6','Login','','admin','admin','2022-01-07','05:08:21 PM','49.35.137.11'),('20220107170822HP3U5MY4ALI','Login','','admin','admin','2022-01-07','05:08:22 PM','49.35.137.11'),('20220107170823GJ7RQ1IAP0X','Login','','admin','admin','2022-01-07','05:08:23 PM','49.35.137.11'),('20220107170825PGLMS7JTWOF','Login','','admin','admin','2022-01-07','05:08:25 PM','49.35.137.11'),('2022011011383159QJKLSHAR2','Login','','admin','admin','2022-01-10','11:38:31 AM','49.35.142.155'),('20220112172801MAS0UL2QPKT','Login','','admin','admin','2022-01-12','05:28:01 PM','110.224.203.159'),('20220115142220JL0YPUO91RD','Login','','admin','admin','2022-01-15','02:22:20 PM','49.35.179.221'),('20220115142224BGRZNQLWF6O','Login','','admin','admin','2022-01-15','02:22:24 PM','49.35.179.221'),('20220117155324QH6VZGP3KD1','Login','','admin','admin','2022-01-17','03:53:24 PM','182.70.208.226'),('20220119114643DEUS91HT28Z','Login','','admin','admin','2022-01-19','11:46:43 AM','49.35.142.151'),('202201191501561HFKGT80XZ6','Login','','admin','admin','2022-01-19','03:01:56 PM','49.35.140.44'),('20220120171134164FMY0BE3I','Login','','admin','admin','2022-01-20','05:11:34 PM','49.35.155.123'),('202203161208066ZUWAR9820V','Login','','admin','admin','2022-03-16','12:08:06 PM','110.227.50.118'),('202203161231168M35GSDC4ZW','NEW Advisor REGISTERED','ID : 2, NAME : Rohit Jatwar','admin','admin','2022-03-16','12:31:16 PM','110.227.50.118'),('202203161243368G5UN931COQ','Login','','admin','admin','2022-03-16','12:43:36 PM','110.227.50.118'),('20220316133453KAO7MGB8DTX','Login','','admin','admin','2022-03-16','01:34:53 PM','110.227.53.118'),('20220316133607UVQP3AWMXK2','NEW PROJECT CREATED','ID : 8, NAME : SHREE RAM PARK','admin','admin','2022-03-16','01:36:07 PM','110.227.53.118'),('20220316133724EVANRWIP7YB','Advisor LEVEL EDITED','ID : 1, OLD : COMPANY NEW : COMPANY','admin','admin','2022-03-16','01:37:24 PM','110.227.53.118'),('20220316133817T091OZC4IVE','Advisor LEVEL EDITED','ID : 3, OLD : LEVEL-2 NEW : LEVEL-2','admin','admin','2022-03-16','01:38:17 PM','110.227.53.118'),('20220316133834RMXZQYI9JCO','Advisor LEVEL EDITED','ID : 3, OLD : LEVEL-2 NEW : LEVEL-1','admin','admin','2022-03-16','01:38:34 PM','110.227.53.118'),('20220316134316QDRV7OB49GP','Advisor LEVEL EDITED','ID : 2, OLD : LEVEL-1 NEW : LEVEL-2','admin','admin','2022-03-16','01:43:16 PM','110.227.53.118'),('20220316134400XYIMD54C8UZ','Advisor LEVEL EDITED','ID : 4, OLD : LEVEL-3 NEW : LEVEL-3','admin','admin','2022-03-16','01:44:00 PM','110.227.53.118'),('20220316134532R9C0NS4OET7','Advisor LEVEL CREATED','ID : 5, TYPE : LEVEL-4','admin','admin','2022-03-16','01:45:32 PM','110.227.53.118'),('20220316134622Z473XFDA5NT','Advisor LEVEL CREATED','ID : 6, TYPE : LEVEL-5','admin','admin','2022-03-16','01:46:22 PM','110.227.53.118'),('202203161349570618BZG3RW5','Advisor LEVEL CREATED','ID : 7, TYPE : LEVEL-6','admin','admin','2022-03-16','01:49:57 PM','110.227.53.118'),('20220316135033ON02LGQX8WR','Advisor LEVEL CREATED','ID : 8, TYPE : LEVEL-7','admin','admin','2022-03-16','01:50:33 PM','110.227.53.118'),('20220316135211DT3VRICF46M','Advisor LEVEL CREATED','ID : 9, TYPE : LEVEL-8','admin','admin','2022-03-16','01:52:11 PM','110.227.53.118'),('20220316135320MOTP51KB049','Advisor LEVEL CREATED','ID : 10, TYPE : LEVEL-9','admin','admin','2022-03-16','01:53:20 PM','110.227.53.118'),('202203161354233QL24COSZ80','Advisor LEVEL CREATED','ID : 11, TYPE : LEVEL-10','admin','admin','2022-03-16','01:54:23 PM','110.227.53.118'),('20220316135531N5MAWTV06KF','Advisor LEVEL CREATED','ID : 12, TYPE : LEVEL-11','admin','admin','2022-03-16','01:55:31 PM','110.227.53.118'),('202203161356273O17M49SHPQ','Advisor LEVEL CREATED','ID : 13, TYPE : LEVEL-12','admin','admin','2022-03-16','01:56:27 PM','110.227.53.118'),('20220316135707MWP8E2OAH16','Advisor LEVEL CREATED','ID : 14, TYPE : LEVEL-13','admin','admin','2022-03-16','01:57:07 PM','110.227.53.118'),('20220316135807BO6U4XT8RML','Advisor LEVEL CREATED','ID : 15, TYPE : LEVEL-14','admin','admin','2022-03-16','01:58:07 PM','110.227.53.118'),('202203161358411FKNMS9XBJ6','Advisor LEVEL CREATED','ID : 16, TYPE : LEVEL-15','admin','admin','2022-03-16','01:58:41 PM','110.227.53.118'),('20220316135946A2TJ4QEO15U','Advisor LEVEL CREATED','ID : 17, TYPE : LEVEL16','admin','admin','2022-03-16','01:59:46 PM','110.227.53.118'),('20220316140012ZU2Q9IF6KDO','Advisor LEVEL CREATED','ID : 18, TYPE : LEVEL-17','admin','admin','2022-03-16','02:00:12 PM','110.227.53.118'),('20220316140150I0OL85NSUF6','Advisor LEVEL CREATED','ID : 19, TYPE : LEVEL-18','admin','admin','2022-03-16','02:01:50 PM','110.227.53.118'),('20220316140244WR74YGETPKL','Advisor PROFILE EDITED','ID : 2, NAME : Rohit Jatwar','admin','admin','2022-03-16','02:02:44 PM','110.227.53.118'),('202203161413157BV3RS8YEHI','Advisor PROFILE EDITED','ID : 2, NAME : RAJENDRA SINGH','admin','admin','2022-03-16','02:13:15 PM','110.227.53.118'),('202203161415572VZOSXI4DQ1','NEW Advisor REGISTERED','ID : 3, NAME : ROHIT KUMAR JATWAR','admin','admin','2022-03-16','02:15:57 PM','110.227.53.118'),('20220316141848K6Y2NTZ3S4W','NEW Advisor REGISTERED','ID : 4, NAME : AKASH SINGH CHOWHAN','admin','admin','2022-03-16','02:18:48 PM','110.227.53.118'),('202203161422223J1SW4Y80ZA','NEW Advisor REGISTERED','ID : 5, NAME : ABHISEK SINGH','admin','admin','2022-03-16','02:22:22 PM','110.227.53.118'),('20220316142426USZXWFBT53D','NEW Advisor REGISTERED','ID : 6, NAME : AVINASH SINGH CHOWHAN','admin','admin','2022-03-16','02:24:26 PM','110.227.53.118'),('20220316142819AF0K6928OJR','PROPERTY BOOKED','ORDER NO ODR0002, AMOUNT : 200000','admin','admin','2022-03-16','02:28:19 PM','110.227.53.118'),('20220316142835HU28FSNTWQV','BOOKING APPROVED','ORDER NO : ODR0002','admin','admin','2022-03-16','02:28:35 PM','110.227.53.118'),('20220316142839STGXQ9JA7V6','BOOKING PAYMENT RECEIVE APPROVED','VOUCHER NO : 0002/DP/0002, ORDER NO :','admin','admin','2022-03-16','02:28:39 PM','110.227.53.118'),('20220316143011BF2THNSJDGR','PAYMENT RECEIVED','ORDER NO ODR0002, AMOUNT : 646000','admin','admin','2022-03-16','02:30:11 PM','110.227.61.68'),('20220316143028YLJCKTUV0XS','BOOKING PAYMENT RECEIVE APPROVED','VOUCHER NO : 0002/INS/0003, ORDER NO :','admin','admin','2022-03-16','02:30:28 PM','110.227.61.68'),('20220316143127SYCBT7UWK5O','Advisor LEVEL EDITED','ID : 19, OLD : LEVEL-18 NEW : LEVEL-18','admin','admin','2022-03-16','02:31:27 PM','110.227.61.68'),('20220316143154R73DGA8CMPX','BOOKING DELETED','ORDER NO : ODR0002, PROJECT : GOLDAN PARK CHHATAUNA, PROPERTY : PLOTS/02, CUSTOMER : Alok Kumar Dubey, CODE : DCTC001, Associate : ROHIT KUMAR JATWAR, CODE : DCT003','admin','admin','2022-03-16','02:31:54 PM','110.227.61.68'),('20220316143232VAWB861FM59','PROPERTY BOOKED','ORDER NO ODR0003, AMOUNT : 300000','admin','admin','2022-03-16','02:32:32 PM','110.227.61.68'),('2022031614325246KEL8DOM2Y','BOOKING APPROVED','ORDER NO : ODR0003','admin','admin','2022-03-16','02:32:52 PM','110.227.61.68'),('20220316143256VCTK15ZQE46','BOOKING PAYMENT RECEIVE APPROVED','VOUCHER NO : 0003/DP/0004, ORDER NO :','admin','admin','2022-03-16','02:32:56 PM','110.227.61.68'),('202203161433499L2AXER4OY5','PROJECT DELETED','ID=2, NAME : GOLDAN PARK CHHATAUNA','admin','admin','2022-03-16','02:33:49 PM','110.227.61.68'),('20220316143353YMG4D69UOKC','PROJECT DELETED','ID=7, NAME : GOLDEN PARK BODRI','admin','admin','2022-03-16','02:33:53 PM','110.227.61.68'),('20220316143357BR0QSIG7894','PROJECT DELETED','ID=3, NAME : INDU IMPERIA','admin','admin','2022-03-16','02:33:57 PM','110.227.61.68'),('20220316171224M4LTJG37EOU','Login','','admin','admin','2022-03-16','05:12:24 PM','110.227.53.68'),('20220317111441SGIPUCXMR7D','Login','','admin','admin','2022-03-17','11:14:41 AM','110.227.55.209'),('20220321121546H7YRNJZDXVP','Login','','admin','admin','2022-03-21','12:15:46 PM','27.62.195.241'),('20220321125306Y3EG2UK0TWQ','PROPERTY ADDED','ON PROJECT : 8, NAME : SHREE RAM PARK, No Of Properties : 10','admin','admin','2022-03-21','12:53:06 PM','27.62.195.241'),('20220321125720QW15HKGD6M9','PROPERTY ADDED','ON PROJECT : 8, NAME : SHREE RAM PARK, No Of Properties : 10','admin','admin','2022-03-21','12:57:20 PM','27.62.195.241'),('20220321130444HBN0WIL1OX5','PROPERTY ADDED','ON PROJECT : 8, NAME : SHREE RAM PARK, No Of Properties : 10','admin','admin','2022-03-21','01:04:44 PM','27.62.195.241'),('20220321131409QYSNJMPW83A','PROPERTY ADDED','ON PROJECT : 8, NAME : SHREE RAM PARK, No Of Properties : 13','admin','admin','2022-03-21','01:14:09 PM','27.62.195.241'),('20220321133008OXPYAFNB5ZJ','PROPERTY ADDED','ON PROJECT : 8, NAME : SHREE RAM PARK, No Of Properties : 10','admin','admin','2022-03-21','01:30:08 PM','27.62.195.241'),('20220321134727Z0F7O8PUNYH','PROPERTY ADDED','ON PROJECT : 8, NAME : SHREE RAM PARK, No Of Properties : 10','admin','admin','2022-03-21','01:47:27 PM','27.62.195.241'),('20220321151730MU3Q079Y2OI','Login','','admin','admin','2022-03-21','03:17:30 PM','27.62.195.241'),('202203211548562FPEWMID5BA','PROPERTY ADDED','ON PROJECT : 8, NAME : SHREE RAM PARK, No Of Properties : 11','admin','admin','2022-03-21','03:48:56 PM','27.62.195.241'),('20220321155210BA62IQL8N7V','PROPERTY ADDED','ON PROJECT : 8, NAME : SHREE RAM PARK, No Of Properties : 10','admin','admin','2022-03-21','03:52:10 PM','27.62.195.241'),('20220321160109W4UMAR0DEN5','PROPERTY ADDED','ON PROJECT : 8, NAME : SHREE RAM PARK, No Of Properties : 11','admin','admin','2022-03-21','04:01:09 PM','27.62.195.241'),('20220321174931S62VQKW9IJ5','PROPERTY ADDED','ON PROJECT : 8, NAME : SHREE RAM PARK, No Of Properties : 15','admin','admin','2022-03-21','05:49:31 PM','27.62.195.241'),('20220321175346BZIEW3GV58D','PROPERTY ADDED','ON PROJECT : 8, NAME : SHREE RAM PARK, No Of Properties : 10','admin','admin','2022-03-21','05:53:46 PM','27.62.195.241'),('20220321175741RLZSCAMYE1T','PROPERTY ADDED','ON PROJECT : 8, NAME : SHREE RAM PARK, No Of Properties : 10','admin','admin','2022-03-21','05:57:41 PM','27.62.195.241'),('20220321180313ZDJQG5NA417','PROPERTY ADDED','ON PROJECT : 8, NAME : SHREE RAM PARK, No Of Properties : 11','admin','admin','2022-03-21','06:03:13 PM','27.62.195.241'),('20220321181812D1WRK8GCXHT','PROPERTY ADDED','ON PROJECT : 8, NAME : SHREE RAM PARK, No Of Properties : 10','admin','admin','2022-03-21','06:18:12 PM','27.62.195.241'),('20220321182132E2VGU4AK91R','PROPERTY ADDED','ON PROJECT : 8, NAME : SHREE RAM PARK, No Of Properties : 10','admin','admin','2022-03-21','06:21:32 PM','27.62.195.241'),('20220321182409FLOZP4ATNGH','PROPERTY ADDED','ON PROJECT : 8, NAME : SHREE RAM PARK, No Of Properties : 8','admin','admin','2022-03-21','06:24:09 PM','27.62.195.241'),('202203221402378PS356V7C41','Login','','admin','admin','2022-03-22','02:02:37 PM','27.62.195.241'),('20220325120745VG6OZFPKX3T','Login','','admin','admin','2022-03-25','12:07:45 PM','27.62.178.17'),('20220326121927JV0P25ABYIK','Login','','admin','admin','2022-03-26','12:19:27 PM','27.62.178.17'),('20220330160814JRL7AEIOC90','Login','','admin','admin','2022-03-30','04:08:14 PM','27.62.178.17'),('20220419161943OITED3WFZKV','Login','','admin','admin','2022-04-19','04:19:43 PM','117.198.16.132'),('20220420143201XSPLYHRNFZ5','Login','','admin','admin','2022-04-20','02:32:01 PM','59.96.121.171'),('20220421120745N36DZHQBMS5','Login','','admin','admin','2022-04-21','12:07:45 PM','117.198.22.135'),('20220421121236NBF0L2WG6C5','Advisor PROFILE EDITED','ID : 1, NAME : DCT REAL ESTATE','admin','admin','2022-04-21','12:12:36 PM','117.198.22.135'),('202204211735399JLGHKU21RC','Login','','admin','admin','2022-04-21','05:35:39 PM','59.88.61.32'),('2022042211432802GVBALPCWY','Login','','admin','admin','2022-04-22','11:43:28 AM','117.198.18.179'),('20220422120421Y8W0TOU29SV','Advisor LEVEL EDITED','ID : 18, OLD : LEVEL-17 NEW : Senior Voice Precident','admin','admin','2022-04-22','12:04:21 PM','117.198.18.179'),('202204221205469DZG8W3UHJT','Advisor LEVEL EDITED','ID : 17, OLD : LEVEL16 NEW : Voice Precident','admin','admin','2022-04-22','12:05:46 PM','117.198.18.179'),('20220422120801VU5CT0P3G6X','Advisor LEVEL EDITED','ID : 16, OLD : LEVEL-15 NEW : Senior Marketing Director','admin','admin','2022-04-22','12:08:01 PM','117.198.18.179'),('20220422120850Z2X7UASEQK8','Advisor LEVEL EDITED','ID : 15, OLD : LEVEL-14 NEW : Marketing Director','admin','admin','2022-04-22','12:08:50 PM','117.198.18.179'),('202204221212107YXFPHGWT6Q','Advisor LEVEL EDITED','ID : 14, OLD : LEVEL-13 NEW : Senior Field Officer','admin','admin','2022-04-22','12:12:10 PM','117.198.18.179'),('20220422121305D9T6KMUQGB3','Advisor LEVEL EDITED','ID : 18, OLD : Senior Voice Precident NEW : Senior Voice Precident','admin','admin','2022-04-22','12:13:05 PM','117.198.18.179'),('20220422121407QI5SOA1M9KX','Advisor LEVEL EDITED','ID : 13, OLD : LEVEL-12 NEW : Field Officer','admin','admin','2022-04-22','12:14:07 PM','117.198.18.179'),('20220422121515C5JOW9N4DTA','Advisor LEVEL EDITED','ID : 12, OLD : LEVEL-11 NEW : Senior Sales Representative','admin','admin','2022-04-22','12:15:15 PM','117.198.18.179'),('20220422121745DV8M9KLUNX6','Advisor LEVEL EDITED','ID : 11, OLD : LEVEL-10 NEW : Sales Representative','admin','admin','2022-04-22','12:17:45 PM','117.198.18.179'),('20220422121936MUGN8CD23W0','Advisor LEVEL EDITED','ID : 10, OLD : LEVEL-9 NEW : Senior Marketing Head','admin','admin','2022-04-22','12:19:36 PM','117.198.18.179'),('20220422122047HR0WLEDXTCF','Advisor LEVEL EDITED','ID : 9, OLD : LEVEL-8 NEW : Marketing Head','admin','admin','2022-04-22','12:20:47 PM','117.198.18.179'),('202204271806101CRTX97SOQ8','Login','','admin','admin','2022-04-27','06:06:10 PM','117.200.43.170'),('20220428112159ADF9WZXE1MS','Login','','admin','admin','2022-04-28','11:21:59 AM','117.198.18.211'),('20220428115642Z25CHMOGE4X','Advisor LEVEL EDITED','ID : 18, OLD : Senior Voice Precident NEW : Senior Vice President','admin','admin','2022-04-28','11:56:42 AM','117.198.18.211'),('20220428115702JD430TFWANQ','Advisor LEVEL EDITED','ID : 17, OLD : Voice Precident NEW : Vice President','admin','admin','2022-04-28','11:57:02 AM','117.198.18.211'),('202204281158172FPBD6KQ7GO','Advisor LEVEL EDITED','ID : 8, OLD : LEVEL-7 NEW : Senior Business Collector','admin','admin','2022-04-28','11:58:17 AM','117.198.18.211'),('20220428115857FPV1BAQ38N2','Advisor LEVEL EDITED','ID : 7, OLD : LEVEL-6 NEW : Business Collector','admin','admin','2022-04-28','11:58:57 AM','117.198.18.211'),('20220428115953YTXVJ49KPI3','Advisor LEVEL EDITED','ID : 6, OLD : LEVEL-5 NEW : Senior Business Development Manager','admin','admin','2022-04-28','11:59:53 AM','117.198.18.211'),('20220428120051XLWJMCF6KBV','Advisor LEVEL EDITED','ID : 5, OLD : LEVEL-4 NEW : Business Development Manager','admin','admin','2022-04-28','12:00:51 PM','117.198.18.211'),('20220428120119AQ3ZY0SGTJW','Advisor LEVEL EDITED','ID : 4, OLD : LEVEL-3 NEW : Senior Sales Manager','admin','admin','2022-04-28','12:01:19 PM','117.198.18.211'),('20220428120358JY0FM5D4AHT','Advisor LEVEL EDITED','ID : 3, OLD : LEVEL-1 NEW : Sales Manager','admin','admin','2022-04-28','12:03:58 PM','117.198.18.211'),('20220428121242JODE5Z1CPFY','Advisor LEVEL EDITED','ID : 2, OLD : LEVEL-2 NEW : Business Associate','admin','admin','2022-04-28','12:12:42 PM','117.198.18.211'),('202204281213081M9FVDGAOB8','Advisor LEVEL EDITED','ID : 3, OLD : Sales Manager NEW : Sales Manager','admin','admin','2022-04-28','12:13:08 PM','117.198.18.211'),('20220428131118ZGF40EPVINY','NEW Advisor REGISTERED','ID : 7, NAME : Abhisekh Kumar Singh','admin','admin','2022-04-28','01:11:18 PM','117.198.18.211'),('20220428134110TF8JCWQ0L4S','Login','','admin','admin','2022-04-28','01:41:10 PM','117.200.43.205'),('2022042813411150MYRA32HZF','Login','','admin','admin','2022-04-28','01:41:11 PM','117.200.43.205'),('20220428135221IS1AJ2D7RKU','Advisor PROFILE EDITED','ID : 3, NAME : ROHIT KUMAR JATWAR','admin','admin','2022-04-28','01:52:21 PM','117.200.43.205'),('20220430155103E8B05YSGINH','Login','','admin','admin','2022-04-30','03:51:03 PM','117.198.17.70'),('20220505112019T5DC9YRLPKW','Login','','admin','admin','2022-05-05','11:20:19 AM','117.198.20.228'),('202205051127253HLMXE8NUOI','NEW Advisor REGISTERED','ID : 8, NAME : Rajnish Manikpuri','admin','admin','2022-05-05','11:27:25 AM','117.198.20.228'),('20220510111855F58YQVXWST3','Login','','admin','admin','2022-05-10','11:18:55 AM','117.200.46.113'),('20220510112238Y86EGQS10WN','Login','','admin','admin','2022-05-10','11:22:38 AM','122.168.157.107'),('202205101136076G2CXJH945S','NEW Advisor REGISTERED','ID : 9, NAME : Jiya Khan','admin','admin','2022-05-10','11:36:07 AM','117.200.46.113'),('20220510125317NVAF7Z1RWEC','Login','','admin','admin','2022-05-10','12:53:17 PM','122.168.157.107'),('20220510125505CRU6WF4TYNS','Advisor PROFILE EDITED','ID : 8, NAME : Rajnish Manikpuri','admin','admin','2022-05-10','12:55:05 PM','122.168.157.107'),('20220510125518E5WZVJ21OT9','Advisor PROFILE EDITED','ID : 9, NAME : Jiya Khan','admin','admin','2022-05-10','12:55:18 PM','122.168.157.107'),('20220511154438G6I1LW3Q5P4','Login','','admin','admin','2022-05-11','03:44:38 PM','59.88.62.42'),('202206011226555QY4BGF0UC2','Login','','admin','admin','2022-06-01','12:26:55 PM','157.34.83.150'),('20220601123254AFU3T5EZDO2','NEW Advisor REGISTERED','ID : 10, NAME : Aditya Bajpai','admin','admin','2022-06-01','12:32:54 PM','157.34.83.150'),('20220602113346HX5O1CEFV03','Login','','admin','admin','2022-06-02','11:33:46 AM','117.200.47.126'),('20220602114046AUYEKO2FTJP','NEW Advisor REGISTERED','ID : 11, NAME : Savita Neeraj vashistha','admin','admin','2022-06-02','11:40:46 AM','117.200.47.126'),('20220602142654JIMK7DFZNRG','Login','','admin','admin','2022-06-02','02:26:54 PM','117.200.47.126'),('2022060318240349KMBTUF025','Login','','admin','admin','2022-06-03','06:24:03 PM','59.88.57.198'),('20220603183312UKN0ZLOT6XS','Login','','admin','admin','2022-06-03','06:33:12 PM','59.88.57.198'),('20220611113429RWNZU84A01C','Login','','admin','admin','2022-06-11','11:34:29 AM','59.96.120.103'),('20220611114048NYLATED9XSK','NEW Advisor REGISTERED','ID : 12, NAME : Taniya Chauhan','admin','admin','2022-06-11','11:40:48 AM','59.96.120.103'),('20220615125750LI9VD5ZTGNU','Login','','admin','admin','2022-06-15','12:57:50 PM','117.200.40.53'),('20220620125027IK1NAFP5LZS','Login','','admin','admin','2022-06-20','12:50:27 PM','117.200.47.55'),('20220625134913LCXUOKR6NQ3','Login','','admin','admin','2022-06-25','01:49:13 PM','59.88.58.70'),('20220625135321XKSYHI1VJCA','NEW PROJECT CREATED','ID : 9, NAME : Krishnapuram','admin','admin','2022-06-25','01:53:21 PM','59.88.58.70'),('20220625160512PNWCB5MYIAZ','Login','','admin','admin','2022-06-25','04:05:12 PM','59.88.58.70');
/*!40000 ALTER TABLE `tbl_admin_user_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_advisor`
--

DROP TABLE IF EXISTS `tbl_advisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_advisor` (
  `advisor_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `advisor_code` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'ID NO',
  `advisor_password` text COLLATE latin1_general_ci NOT NULL,
  `advisor_sponsor` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Introducer Or Parent',
  `advisor_level_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `advisor_title` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `advisor_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `advisor_fname` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `advisor_sex` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `advisor_address` text COLLATE latin1_general_ci NOT NULL,
  `advisor_mobile` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `advisor_phone` varchar(12) COLLATE latin1_general_ci NOT NULL,
  `advisor_email` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `advisor_whatsapp_no` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `advisor_marital_status` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `advisor_bg` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `advisor_dob` date NOT NULL,
  `advisor_anniversary_date` date NOT NULL,
  `advisor_hire_date` date NOT NULL,
  `advisor_qualification` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `advisor_occupation` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `advisor_pan_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `advisor_photo` text COLLATE latin1_general_ci NOT NULL,
  `advisor_status` int(1) NOT NULL COMMENT 'iF aCTIVE THEN 1 ORHER WISE 0',
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  `last_access_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`advisor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_advisor`
--

LOCK TABLES `tbl_advisor` WRITE;
/*!40000 ALTER TABLE `tbl_advisor` DISABLE KEYS */;
INSERT INTO `tbl_advisor` (`advisor_id`, `advisor_code`, `advisor_password`, `advisor_sponsor`, `advisor_level_id`, `advisor_title`, `advisor_name`, `advisor_fname`, `advisor_sex`, `advisor_address`, `advisor_mobile`, `advisor_phone`, `advisor_email`, `advisor_whatsapp_no`, `advisor_marital_status`, `advisor_bg`, `advisor_dob`, `advisor_anniversary_date`, `advisor_hire_date`, `advisor_qualification`, `advisor_occupation`, `advisor_pan_no`, `advisor_photo`, `advisor_status`, `created_details`, `edited_details`, `last_access_details`) VALUES (1,'DCT001','21232f297a57a5a743894a0e4a801fc3','','1','MR.','DCT REAL ESTATE','DCT','MALE','..','7223095090','','companydct242@gmail.com','7223095090','Unmarried','..','1900-01-01','1900-01-01','2021-12-31','..','..','..','',1,'admin, admin, 2021-12-31, 11:16:24 AM, 122.175.171.134','admin, admin, 2022-04-21, 12:12:36 PM, 117.198.22.135',''),(2,'DCT002','2b363f395239c1b23d60b4b7d90293e8','1','19','MR.','RAJENDRA SINGH','.','MALE','House No.12 , Akash Vihar Baima Nagoi Road, Sarkanda , Bilaspur, (C.G)','9898989898','','rohitjatwar@gmail.com','7770826767','Married','o+','1979-04-05','2004-04-28','2021-01-01','higher Secondary','Business','ALNPJ3474D','',1,'admin, admin, 2022-03-16, 12:31:16 PM, 110.227.50.118','admin, admin, 2022-03-16, 02:13:15 PM, 110.227.53.118',''),(3,'DCT003','27fc234443a7e6f2d18910801d1336c8','1','18','MR.','ROHIT KUMAR JATWAR','SHRI RAM LAL JATWAR','MALE','H/NO.12 AKASH VIHAR, BAIMA NAGOI ROAD,BILASPUR','7770826767','','rohitjatwar@gmail.com','7770826767','Married','O+','1979-05-04','2004-04-28','2022-03-16','HR. SEC.','BUSINESSMAN','ALNPJ3474D','',1,'admin, admin, 2022-03-16, 02:15:57 PM, 110.227.53.118','admin, admin, 2022-04-28, 01:52:21 PM, 117.200.43.205','2022-04-21, 12:10:22 PM, 117.198.22.135'),(4,'DCT004','27fc234443a7e6f2d18910801d1336c8','1','18','MR.','AKASH SINGH CHOWHAN','SHANKAR SINGH CHOWHAN','MALE','TIKRAPARA,BILASPUR','7389980611','','aakash50272@gmail.com','','Unmarried','','1988-10-06','2016-04-26','2022-03-16','B TECH','BUSINESSMAN','ATFPC1193E','',1,'admin, admin, 2022-03-16, 02:18:48 PM, 110.227.53.118','admin, admin, 2022-03-16, 02:18:48 PM, 110.227.53.118',''),(5,'DCT005','27fc234443a7e6f2d18910801d1336c8','1','18','MR.','ABHISEK SINGH','ICHCHAA SINGH','MALE','..','6005538340','','abhisek@gmail.com','','Unmarried','','1900-01-01','1900-01-01','2022-03-16','..','..','..','',1,'admin, admin, 2022-03-16, 02:22:22 PM, 110.227.53.118','admin, admin, 2022-03-16, 02:22:22 PM, 110.227.53.118',''),(6,'DCT006','27fc234443a7e6f2d18910801d1336c8','1','18','MR.','AVINASH SINGH CHOWHAN','SHANKAR SINGH CHOWHAN','MALE','BILASPUR','7869004148','','avinash.chowhan07@gmail.com','','Unmarried','','1900-01-01','1900-01-01','2022-03-16','B.COM','BUSINESS','ASCPC9301L','',1,'admin, admin, 2022-03-16, 02:24:26 PM, 110.227.53.118','admin, admin, 2022-03-16, 02:24:26 PM, 110.227.53.118',''),(7,'DCT007','27fc234443a7e6f2d18910801d1336c8','3','17','MR.','Abhisekh Kumar Singh','Let. Mr.Janmejay Singh','MALE','Plot No. 78 Kosabadi Korba','9060527458','','abhisheksinghsqi@gmail.com','9060527458','Married','B+','1988-07-01','2013-01-01','2022-04-28','MA English II','BUSINESSMAN','','',1,'admin, admin, 2022-04-28, 01:11:18 PM, 117.198.18.211','admin, admin, 2022-04-28, 01:11:18 PM, 117.198.18.211',''),(8,'DCT008','27fc234443a7e6f2d18910801d1336c8','2','2','MRS.','Rajnish Manikpuri','Mr. Kamal Das','FEMALE','Chhatauna, Post - Hirri Mines, Bilaspur (C.G)','9343871020','9343871020','rajnishmanikpuri5@gmail.com','','Married','','1994-10-22','1900-01-01','2022-05-05','BA/DCA Running','employee','','',1,'admin, admin, 2022-05-05, 11:27:25 AM, 117.198.20.228','admin, admin, 2022-05-10, 12:55:05 PM, 122.168.157.107',''),(9,'DCT009','27fc234443a7e6f2d18910801d1336c8','2','2','MISS','Jiya Khan','Mr. Firoz Khan','FEMALE','Vidya Nagar, Bilaspur (C.G)','7999618165','','jkhan4065W@gmail.com','7999618165','Unmarried','','1997-01-12','1997-07-12','2022-05-10','M.Com+ Tally','Accountant','','',1,'admin, admin, 2022-05-10, 11:36:07 AM, 117.200.46.113','admin, admin, 2022-05-10, 12:55:18 PM, 122.168.157.107',''),(10,'DCT010','16626d7b6d3b00c6fdb368689b2f672c','2','1','MR.','Aditya Bajpai','Mr. Om Prakash Bajpai','MALE','S/O Om Prakash Bajpai, Imlipara, Bilaspur.(C.G)','8305630069','','adityabajpai84@gmail.com','8305630069','Unmarried','','1994-12-27','1900-01-01','2022-06-01','Diploma computer Sci','employee','ECQPB4751P','',1,'admin, admin, 2022-06-01, 12:32:54 PM, 157.34.83.150','admin, admin, 2022-06-01, 12:32:54 PM, 157.34.83.150',''),(11,'DCT011','16626d7b6d3b00c6fdb368689b2f672c','2','1','MRS.','Savita Neeraj vashistha','Mr. Neeraj Vashistha','FEMALE','Yadunandan Nagar, Tifra., Bilaspur(C.G)','7587257931','','s.n.vashistha0@gmail.com','7587257931','Married','B+','1984-10-03','2012-07-17','2022-06-01','Bsc/LLB/Pgdca/ITI(Dr','employee','','',1,'admin, admin, 2022-06-02, 11:40:46 AM, 117.200.47.126','admin, admin, 2022-06-02, 11:40:46 AM, 117.200.47.126',''),(12,'DCT012','16626d7b6d3b00c6fdb368689b2f672c','2','1','MISS','Taniya Chauhan','Mr.Bhojram Chauchan','FEMALE','Hirri Mines Ram Nagar Bilaspur(C.G)','8889466785','','taniyachouchan273@gmail.com','8889466785','Unmarried','A+ Positive','1997-08-10','1900-01-01','2022-06-10','PG','employee','','',1,'admin, admin, 2022-06-11, 11:40:48 AM, 59.96.120.103','admin, admin, 2022-06-11, 11:40:48 AM, 59.96.120.103','');
/*!40000 ALTER TABLE `tbl_advisor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_advisor_action`
--

DROP TABLE IF EXISTS `tbl_advisor_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_advisor_action` (
  `action_id` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `action_on` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `action_user_id` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_user_date` date NOT NULL,
  `action_user_time` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_user_ip` varchar(30) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`action_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_advisor_action`
--

LOCK TABLES `tbl_advisor_action` WRITE;
/*!40000 ALTER TABLE `tbl_advisor_action` DISABLE KEYS */;
INSERT INTO `tbl_advisor_action` (`action_id`, `action_name`, `action_on`, `action_user_id`, `action_user_date`, `action_user_time`, `action_user_ip`) VALUES ('20220419165436103HNTW5DAI','Login','','DCT003','2022-04-19','04:54:36 PM','117.198.16.132'),('20220421120925ZI1HGKVL2NR','Login','','DCT003','2022-04-21','12:09:25 PM','117.198.22.135');
/*!40000 ALTER TABLE `tbl_advisor_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_advisor_commission`
--

DROP TABLE IF EXISTS `tbl_advisor_commission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_advisor_commission` (
  `commission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `commission_order_no` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Order No From Booking Table',
  `commission_voucher_no` varchar(50) COLLATE latin1_general_ci NOT NULL COMMENT 'Unique No From Booking Or Payment',
  `commission_project_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `commission_property_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `commission_property_type` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `commission_particular` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Toke, Down Payment Or Installment',
  `commission_date` date NOT NULL,
  `commission_voucher_date` date NOT NULL,
  `commission_customer_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `commission_advisor_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `commission_advisor_level_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'At The Time Of Booking Level Of Advisor According To which Commission Will Be Distributed',
  `commission_advisor_current_level_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'At The Time Of Commission Generation Level Of Getting Advisor',
  `commission_advisor_level_percent` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Level Percent at The Time Of Booking',
  `commission_advisor_level_diff_percent` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'According Which Commission Will Be Generated',
  `commission_amount` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Distributed Commission Of Advisor',
  `commission_tds_percent` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'TDS Percent From tbl_setting_tds',
  `commission_tds_amount` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'TDS Amount',
  `commission_nett_amount` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Commission After TDS Cut Off',
  `commission_voucher_amount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `commission_by_advisor_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Advisor Who Booked The Property',
  `commission_by` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Self Or Reference',
  `approved` tinyint(1) NOT NULL,
  PRIMARY KEY (`commission_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_advisor_commission`
--

LOCK TABLES `tbl_advisor_commission` WRITE;
/*!40000 ALTER TABLE `tbl_advisor_commission` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_advisor_commission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_advisor_dvr`
--

DROP TABLE IF EXISTS `tbl_advisor_dvr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_advisor_dvr` (
  `dvr_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `advisor_id` bigint(20) NOT NULL,
  `project_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `property_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `customer_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `mobile_no` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `occupation` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `city` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `address` text COLLATE latin1_general_ci NOT NULL,
  `response1` text COLLATE latin1_general_ci NOT NULL,
  `response2` text COLLATE latin1_general_ci NOT NULL,
  `response3` text COLLATE latin1_general_ci NOT NULL,
  `response4` text COLLATE latin1_general_ci NOT NULL,
  `response5` text COLLATE latin1_general_ci NOT NULL,
  `remarks` text COLLATE latin1_general_ci NOT NULL,
  `status` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `dvr_date` date NOT NULL,
  `remind_date` date NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`dvr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_advisor_dvr`
--

LOCK TABLES `tbl_advisor_dvr` WRITE;
/*!40000 ALTER TABLE `tbl_advisor_dvr` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_advisor_dvr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_advisor_payment`
--

DROP TABLE IF EXISTS `tbl_advisor_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_advisor_payment` (
  `payment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `payment_advisor_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `payment_amount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_bank` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_date` date NOT NULL,
  `payment_remark` text COLLATE latin1_general_ci NOT NULL,
  `approved` tinyint(1) NOT NULL COMMENT '0 for pending 1 for approved',
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_advisor_payment`
--

LOCK TABLES `tbl_advisor_payment` WRITE;
/*!40000 ALTER TABLE `tbl_advisor_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_advisor_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_advisor_promotion`
--

DROP TABLE IF EXISTS `tbl_advisor_promotion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_advisor_promotion` (
  `promotion_id` bigint(18) NOT NULL AUTO_INCREMENT,
  `advisor_id` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `prev_level_id` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `promoted_level_id` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `promotion_date` date NOT NULL,
  `promotion_time` time NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`promotion_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_advisor_promotion`
--

LOCK TABLES `tbl_advisor_promotion` WRITE;
/*!40000 ALTER TABLE `tbl_advisor_promotion` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_advisor_promotion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_award`
--

DROP TABLE IF EXISTS `tbl_award`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_award` (
  `award_id` bigint(18) NOT NULL AUTO_INCREMENT,
  `award` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`award_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_award`
--

LOCK TABLES `tbl_award` WRITE;
/*!40000 ALTER TABLE `tbl_award` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_award` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_complain`
--

DROP TABLE IF EXISTS `tbl_complain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_complain` (
  `complain_id` bigint(18) NOT NULL AUTO_INCREMENT,
  `complain` text COLLATE latin1_general_ci NOT NULL,
  `advisor_id` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `complain_from` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`complain_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_complain`
--

LOCK TABLES `tbl_complain` WRITE;
/*!40000 ALTER TABLE `tbl_complain` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_complain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_customer`
--

DROP TABLE IF EXISTS `tbl_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_customer` (
  `customer_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `customer_code` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `customer_password` text COLLATE latin1_general_ci NOT NULL,
  `customer_title` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `customer_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `customer_fname` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `customer_mobile` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `customer_phone` varchar(12) COLLATE latin1_general_ci NOT NULL,
  `customer_email` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `customer_whatsapp_no` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `customer_marital_status` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `customer_sex` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `customer_bg` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `customer_dob` date NOT NULL,
  `customer_anniversary_date` date NOT NULL,
  `customer_reg_date` date NOT NULL,
  `customer_pan` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `customer_address` text COLLATE latin1_general_ci NOT NULL,
  `customer_city` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `customer_photo` text COLLATE latin1_general_ci NOT NULL,
  `customer_occupation` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `customer_designation` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `customer_anual_income` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `customer_nominee_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `customer_nominee_dob` date NOT NULL,
  `customer_relation_with_nominee` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `customer_nominee_mobile` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `customer_nominee_phone` varchar(12) COLLATE latin1_general_ci NOT NULL,
  `customer_nominee_address` text COLLATE latin1_general_ci NOT NULL,
  `customer_status` tinyint(1) NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  `last_access_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_customer`
--

LOCK TABLES `tbl_customer` WRITE;
/*!40000 ALTER TABLE `tbl_customer` DISABLE KEYS */;
INSERT INTO `tbl_customer` (`customer_id`, `customer_code`, `customer_password`, `customer_title`, `customer_name`, `customer_fname`, `customer_mobile`, `customer_phone`, `customer_email`, `customer_whatsapp_no`, `customer_marital_status`, `customer_sex`, `customer_bg`, `customer_dob`, `customer_anniversary_date`, `customer_reg_date`, `customer_pan`, `customer_address`, `customer_city`, `customer_photo`, `customer_occupation`, `customer_designation`, `customer_anual_income`, `customer_nominee_name`, `customer_nominee_dob`, `customer_relation_with_nominee`, `customer_nominee_mobile`, `customer_nominee_phone`, `customer_nominee_address`, `customer_status`, `created_details`, `edited_details`, `last_access_details`) VALUES (1,'DCTC001','cb21a1f61d7f5e0cefb4d0227fe503d8','MR.','Alok Kumar Dubey','Mr. Dubey','6232966630','','dubey@gmail.com','6232966630','Married','MALE','b+','1900-01-01','1900-01-01','2022-01-04','','bnmn','Bilaspur','','Advocate','...','1000000','Mr.Dubey','1900-01-01','Father','6232966630','6232966630','vhvj',1,'admin, admin, 2022-01-04, 05:16:39 PM, 110.224.175.42','admin, admin, 2022-01-04, 05:16:39 PM, 110.224.175.42','');
/*!40000 ALTER TABLE `tbl_customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_customer_action`
--

DROP TABLE IF EXISTS `tbl_customer_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_customer_action` (
  `action_id` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `action_on` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `action_user_id` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_user_date` date NOT NULL,
  `action_user_time` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `action_user_ip` varchar(30) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`action_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_customer_action`
--

LOCK TABLES `tbl_customer_action` WRITE;
/*!40000 ALTER TABLE `tbl_customer_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_customer_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_enquiry`
--

DROP TABLE IF EXISTS `tbl_enquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_enquiry` (
  `enquiry_id` bigint(18) NOT NULL AUTO_INCREMENT,
  `project_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `property_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `customer_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `mobile_no` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `occupation` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `city` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `address` text COLLATE latin1_general_ci NOT NULL,
  `response1` text COLLATE latin1_general_ci NOT NULL,
  `response2` text COLLATE latin1_general_ci NOT NULL,
  `response3` text COLLATE latin1_general_ci NOT NULL,
  `response4` text COLLATE latin1_general_ci NOT NULL,
  `response5` text COLLATE latin1_general_ci NOT NULL,
  `remarks` text COLLATE latin1_general_ci NOT NULL,
  `status` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `enquiry_date` date NOT NULL,
  `remind_date` date NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`enquiry_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_enquiry`
--

LOCK TABLES `tbl_enquiry` WRITE;
/*!40000 ALTER TABLE `tbl_enquiry` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_enquiry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_expense`
--

DROP TABLE IF EXISTS `tbl_expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_expense` (
  `expense_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `expense_category_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `expense_sub_category_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `expense_party` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `expense_credit_debit` varchar(10) COLLATE latin1_general_ci NOT NULL COMMENT 'Credit Or Debit',
  `expense_amount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `expense_date` date NOT NULL,
  `payment_mode` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `payment_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `payment_bank` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_date` date NOT NULL,
  `expense_note` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`expense_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_expense`
--

LOCK TABLES `tbl_expense` WRITE;
/*!40000 ALTER TABLE `tbl_expense` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_expense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_expense_category`
--

DROP TABLE IF EXISTS `tbl_expense_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_expense_category` (
  `category_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_expense_category`
--

LOCK TABLES `tbl_expense_category` WRITE;
/*!40000 ALTER TABLE `tbl_expense_category` DISABLE KEYS */;
INSERT INTO `tbl_expense_category` (`category_id`, `category_name`) VALUES (1,'BILL');
/*!40000 ALTER TABLE `tbl_expense_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_expense_sub_category`
--

DROP TABLE IF EXISTS `tbl_expense_sub_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_expense_sub_category` (
  `sub_category_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_expense_category',
  `sub_category_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`sub_category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_expense_sub_category`
--

LOCK TABLES `tbl_expense_sub_category` WRITE;
/*!40000 ALTER TABLE `tbl_expense_sub_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_expense_sub_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_project`
--

DROP TABLE IF EXISTS `tbl_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_project` (
  `project_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `project_address` text COLLATE latin1_general_ci NOT NULL,
  `project_photo` text COLLATE latin1_general_ci NOT NULL,
  `project_mouza` text COLLATE latin1_general_ci NOT NULL,
  `project_ph_no` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_1` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_2` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_3` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_4` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_5` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_6` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_amount_1` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_amount_2` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_amount_3` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_amount_4` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_amount_5` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `extra_charge_amount_6` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_project`
--

LOCK TABLES `tbl_project` WRITE;
/*!40000 ALTER TABLE `tbl_project` DISABLE KEYS */;
INSERT INTO `tbl_project` (`project_id`, `project_name`, `project_address`, `project_photo`, `project_mouza`, `project_ph_no`, `extra_charge_1`, `extra_charge_2`, `extra_charge_3`, `extra_charge_4`, `extra_charge_5`, `extra_charge_6`, `extra_charge_amount_1`, `extra_charge_amount_2`, `extra_charge_amount_3`, `extra_charge_amount_4`, `extra_charge_amount_5`, `extra_charge_amount_6`, `created_details`, `edited_details`) VALUES (9,'Krishnapuram','Near Bilha, Hirri thana.','20220625_135321WhatsApp_Image_2022-06-10_at_8.37.17_PM.jpeg','.','.','Development Charge','','','','','','27000','','','','','','admin, admin, 2022-06-25, 01:53:21 PM, 59.88.58.70','admin, admin, 2022-06-25, 01:53:21 PM, 59.88.58.70'),(8,'SHREE RAM PARK','SAKRI','','..','..','','','','','','','','','','','','','admin, admin, 2022-03-16, 01:36:07 PM, 110.227.53.118','admin, admin, 2022-03-16, 01:36:07 PM, 110.227.53.118');
/*!40000 ALTER TABLE `tbl_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_project_details`
--

DROP TABLE IF EXISTS `tbl_project_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_project_details` (
  `project_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `project_property_type_id` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_setting_property_type',
  `project_standard_amount_percent` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `project_no_of_date_to_tokent_expiry` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'numeric or float'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_project_details`
--

LOCK TABLES `tbl_project_details` WRITE;
/*!40000 ALTER TABLE `tbl_project_details` DISABLE KEYS */;
INSERT INTO `tbl_project_details` (`project_id`, `project_property_type_id`, `project_standard_amount_percent`, `project_no_of_date_to_tokent_expiry`) VALUES ('9','1','0','0'),('8','7','100000','45'),('8','1','100000','45');
/*!40000 ALTER TABLE `tbl_project_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_project_property_type_rate`
--

DROP TABLE IF EXISTS `tbl_project_property_type_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_project_property_type_rate` (
  `project_id` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `property_type_id` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `plot_area_rate` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `built_up_area_rate` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `super_built_up_area_rate` varchar(18) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_project_property_type_rate`
--

LOCK TABLES `tbl_project_property_type_rate` WRITE;
/*!40000 ALTER TABLE `tbl_project_property_type_rate` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_project_property_type_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property`
--

DROP TABLE IF EXISTS `tbl_property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property` (
  `property_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `property_project_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary key of tbl_project',
  `property_type_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary key of tbl_setting_property_type',
  `property_no` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Display Name In Every Where',
  `property_status` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Available, Booked Or TempBooked',
  `property_plot_area` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Total Plot Area',
  `property_built_up_area` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'if Property Type not like Plots',
  `property_super_built_up_area` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'if Property Type not like Plots',
  `property_khasra_no` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `property_remarks` text COLLATE latin1_general_ci NOT NULL,
  `property_photo` text COLLATE latin1_general_ci NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`property_id`)
) ENGINE=MyISAM AUTO_INCREMENT=244 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property`
--

LOCK TABLES `tbl_property` WRITE;
/*!40000 ALTER TABLE `tbl_property` DISABLE KEYS */;
INSERT INTO `tbl_property` (`property_id`, `property_project_id`, `property_type_id`, `property_no`, `property_status`, `property_plot_area`, `property_built_up_area`, `property_super_built_up_area`, `property_khasra_no`, `property_remarks`, `property_photo`, `created_details`, `edited_details`) VALUES (101,'8','1','27','Available','1200','0','0','','','','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241'),(100,'8','1','26','Available','1200','0','0','','','','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241'),(99,'8','1','25','Available','1200','0','0','','','','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241'),(97,'8','1','23','Available','1200','0','0','','','','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241'),(98,'8','1','24','Available','1200','0','0','','','','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241'),(96,'8','1','22','Available','1320','0','0','','','','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241'),(95,'8','1','21','Available','1350','0','0','','','','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241'),(94,'8','1','20','Available','1350','0','0','','','','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241'),(92,'8','1','18','Available','1681','0','0','','','','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241'),(93,'8','1','19','Available','1350','0','0','','','','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241'),(91,'8','1','17','Available','1260','0','0','','','','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241'),(90,'8','1','16','Available','1210','0','0','','','','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241'),(89,'8','1','15','Available','1210','0','0','','','','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241'),(88,'8','1','14','Available','1210','0','0','','','','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241'),(87,'8','1','13','Available','1210','0','0','','','','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241'),(86,'8','1','12','Available','1210','0','0','','','','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241'),(85,'8','1','11','Available','1210','0','0','','','','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:57:20 PM, 27.62.195.241'),(84,'8','1','10','Available','1210','0','0','','','','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241'),(83,'8','1','09','Available','1210','0','0','','','','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241'),(75,'8','1','01','Available','1065','0','0','`','','','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241'),(76,'8','1','02','Available','1065','0','0','','','','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241'),(77,'8','1','03','Available','1065','0','0','','','','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241'),(78,'8','1','04','Available','1065','0','0','','','','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241'),(79,'8','1','05','Available','1065','0','0','','','','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241'),(80,'8','1','06','Available','1210','0','0','','','','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241'),(81,'8','1','07','Available','1210','0','0','','','','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241'),(82,'8','1','08','Available','1210','0','0','','','','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241','admin, admin, 2022-03-21, 12:53:06 PM, 27.62.195.241'),(134,'8','1','60','Available','1008','0','0','','','','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241'),(133,'8','1','59','Available','1008','0','0','','','','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241'),(132,'8','1','58','Available','1012','0','0','','','','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241'),(131,'8','1','57','Available','1365','0','0','','','','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241'),(130,'8','1','56','Available','937','0','0','','','','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241'),(129,'8','1','55','Available','1361.25','0','0','','','','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241'),(128,'8','1','54','Available','1361.25','0','0','','','','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241'),(127,'8','1','53','Available','1361.25','0','0','','','','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241'),(126,'8','1','52','Available','1361.25','0','0','','','','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241'),(125,'8','1','51','Available','1331','0','0','','','','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241'),(124,'8','1','50','Available','1210','0','0','','','','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241'),(123,'8','1','49','Available','1210','0','0','','','','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241'),(122,'8','1','48','Available','1210','0','0','','','','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241'),(121,'8','1','47','Available','1210','0','0','','','','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241'),(120,'8','1','46','Available','1210','0','0','','','','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241'),(119,'8','1','45','Available','1210','0','0','','','','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241'),(118,'8','1','44','Available','1210','0','0','','','','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:30:08 PM, 27.62.195.241'),(117,'8','1','43','Available','1361.25','0','0','','','','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241'),(116,'8','1','42','Available','1361.25','0','0','','','','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241'),(115,'8','1','41','Available','1361.25','0','0','','','','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241'),(114,'8','1','40','Available','1361.25','0','0','','','','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241'),(113,'8','1','39','Available','1361.25','0','0','','','','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241'),(112,'8','1','38','Available','1694','0','0','','','','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241'),(111,'8','1','37','Available','1380','0','0','','','','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241'),(110,'8','1','36','Available','1350','0','0','','','','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241'),(109,'8','1','35','Available','1350','0','0','','','','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241'),(108,'8','1','34','Available','1350','0','0','','','','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241'),(107,'8','1','33','Available','1350','0','0','','','','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241'),(106,'8','1','32','Available','1350','0','0','','','','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241'),(105,'8','1','31','Available','1350','0','0','','','','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:14:09 PM, 27.62.195.241'),(104,'8','1','30','Available','1350','0','0','','','','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241'),(103,'8','1','29','Available','1200','0','0','','','','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241'),(102,'8','1','28','Available','1200','0','0','','','','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:04:44 PM, 27.62.195.241'),(135,'8','1','61','Available','1008','0','0','','','','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241'),(136,'8','1','62','Available','1008','0','0','','','','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241'),(137,'8','1','63','Available','1012.50','0','0','','','','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241','admin, admin, 2022-03-21, 01:47:27 PM, 27.62.195.241'),(138,'8','1','64','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241'),(139,'8','1','65','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241'),(140,'8','1','66','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241'),(141,'8','1','67','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241'),(142,'8','1','68','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241'),(143,'8','1','69','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241'),(144,'8','1','70','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241'),(145,'8','1','71','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241'),(146,'8','1','72','Available','1150','0','0','','','','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241'),(147,'8','1','73','Available','1150','0','0','','','','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241'),(148,'8','1','74','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:48:56 PM, 27.62.195.241'),(149,'8','1','75','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241'),(150,'8','1','76','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241'),(151,'8','1','77','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241'),(152,'8','1','78','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241'),(153,'8','1','79','Available','1150','0','0','','','','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241'),(154,'8','1','80','Available','1150','0','0','','','','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241'),(155,'8','1','81','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241'),(156,'8','1','82','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241'),(157,'8','1','83','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241'),(158,'8','1','84','Available','1000','0','0','','','','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241','admin, admin, 2022-03-21, 03:52:10 PM, 27.62.195.241'),(159,'8','1','85','Available','1000','0','0','','','','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241'),(160,'8','1','86','Available','1000','0','0','','','','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241'),(161,'8','1','87','Available','1000','0','0','','','','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241'),(162,'8','1','88','Available','1000','0','0','','','','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241'),(163,'8','1','89','Available','1000','0','0','','','','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241'),(164,'8','1','90','Available','1125','0','0','','','','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241'),(165,'8','1','91','Available','752','0','0','','','','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241'),(166,'8','1','92','Available','1000','0','0','','','','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241'),(167,'8','1','93','Available','1000','0','0','','','','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241'),(168,'8','1','94','Available','1000','0','0','','','','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241'),(169,'8','1','95','Available','1000','0','0','','','','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 04:01:09 PM, 27.62.195.241'),(170,'8','1','96','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241'),(171,'8','1','97','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241'),(172,'8','1','98','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241'),(173,'8','1','99','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241'),(174,'8','1','100','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241'),(175,'8','1','101','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241'),(176,'8','1','102','Available','1150','0','0','','','','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241'),(177,'8','1','103','Available','1150','0','0','','','','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241'),(178,'8','1','104','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241'),(179,'8','1','105','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241'),(180,'8','1','106','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241'),(181,'8','1','107','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241'),(182,'8','1','108','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241'),(183,'8','1','109','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241'),(184,'8','1','110','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:49:31 PM, 27.62.195.241'),(185,'8','1','111','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241'),(186,'8','1','112','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241'),(187,'8','1','113','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241'),(188,'8','1','114','Available','1000','0','0','','','','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241'),(189,'8','1','115','Available','935','0','0','','','','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241'),(190,'8','1','116','Available','1035','0','0','','','','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241'),(191,'8','1','117','Available','1027','0','0','','','','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241'),(192,'8','1','118','Available','1033','0','0','','','','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241'),(193,'8','1','119','Available','1045','0','0','','','','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241'),(194,'8','1','120','Available','1058','0','0','','','','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:53:46 PM, 27.62.195.241'),(195,'8','1','121','Available','800','0','0','','','','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241'),(196,'8','1','122','Available','788','0','0','','','','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241'),(197,'8','1','123','Available','683','0','0','','','','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241'),(198,'8','1','124','Available','1512.50','0','0','','','','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241'),(199,'8','1','125','Available','1512.50','0','0','','','','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241'),(200,'8','1','126','Available','1512.50','0','0','','','','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241'),(201,'8','1','127','Available','1542.75','0','0','','','','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241'),(202,'8','1','128','Available','1530','0','0','','','','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241'),(203,'8','1','129','Available','1500','0','0','','','','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241'),(204,'8','1','130','Available','1500','0','0','','','','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241','admin, admin, 2022-03-21, 05:57:41 PM, 27.62.195.241'),(205,'8','1','131','Available','1500','0','0','','','','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241'),(206,'8','1','132','Available','1530','0','0','','','','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241'),(207,'8','1','133','Available','1380','0','0','','','','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241'),(208,'8','1','134','Available','1380','0','0','','','','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241'),(209,'8','1','135','Available','1380','0','0','','','','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241'),(210,'8','1','136','Available','1380','0','0','','','','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241'),(211,'8','1','137','Available','1380','0','0','','','','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241'),(212,'8','1','138','Available','3470','0','0','','','','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241'),(213,'8','1','139','Available','1965','0','0','','','','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241'),(214,'8','1','140','Available','1950','0','0','','','','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241'),(215,'8','1','141','Available','1950','0','0','','','','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:03:13 PM, 27.62.195.241'),(216,'8','1','L-01','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241'),(217,'8','1','L-02','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241'),(218,'8','1','L-03','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241'),(219,'8','1','L-04','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241'),(220,'8','1','L-05','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241'),(221,'8','1','L-06','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241'),(222,'8','1','L-07','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241'),(223,'8','1','L-08','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241'),(224,'8','1','L-09','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241'),(225,'8','1','L-10','Available','600','0','0','347/2','','','admin, admin, 2022-03-21, 06:18:12 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:25:57 PM, 27.62.195.241'),(226,'8','1','L-11','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241'),(227,'8','1','L-12','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241'),(228,'8','1','L-13','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241'),(229,'8','1','L-14','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241'),(230,'8','1','L-15','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241'),(231,'8','1','L-16','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241'),(232,'8','1','L-17','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241'),(233,'8','1','L-18','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241'),(234,'8','1','L-19','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241'),(235,'8','1','L-20','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:21:32 PM, 27.62.195.241'),(236,'8','1','L-21','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:24:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:24:09 PM, 27.62.195.241'),(237,'8','1','L-22','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:24:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:24:09 PM, 27.62.195.241'),(238,'8','1','L-23','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:24:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:24:09 PM, 27.62.195.241'),(239,'8','1','L-24','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:24:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:24:09 PM, 27.62.195.241'),(240,'8','1','L-25','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:24:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:24:09 PM, 27.62.195.241'),(241,'8','1','L-26','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:24:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:24:09 PM, 27.62.195.241'),(242,'8','1','L-27','Available','600','0','0','','','','admin, admin, 2022-03-21, 06:24:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:24:09 PM, 27.62.195.241'),(243,'8','1','L-28','Available','617','0','0','','','','admin, admin, 2022-03-21, 06:24:09 PM, 27.62.195.241','admin, admin, 2022-03-21, 06:24:09 PM, 27.62.195.241');
/*!40000 ALTER TABLE `tbl_property` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property_booking`
--

DROP TABLE IF EXISTS `tbl_property_booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property_booking` (
  `booking_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_type` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Temporarily/Token or Permanent with Down Payment',
  `booking_commission_status` int(1) NOT NULL COMMENT 'If 1 then Comission Distributed if 0 then not distributed, kept for Next DP/INST',
  `booking_particular` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `booking_voucher_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `booking_date` date NOT NULL,
  `booking_token_exp_date` date NOT NULL COMMENT 'If Temporarily Booked By Token',
  `booking_project_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_project',
  `booking_property_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_property',
  `booking_order_no` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Booking Auto Number',
  `booking_customer_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_customer',
  `booking_executive_type` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Advisor Or Sales Executive',
  `booking_advisor_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_advisor',
  `booking_advisor_level` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Level Of Advisor at the time of booking',
  `booking_advisor_level_percent` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Level Percent  Of Booked By Advisor At The Time Of Booking',
  `booking_advisor_team` text COLLATE latin1_general_ci NOT NULL COMMENT 'Array of Sponsors Sepatated by , (At The Time Of Booking)',
  `booking_advisor_team_level` text COLLATE latin1_general_ci NOT NULL COMMENT 'Array of Sponsors Level Sepatated by ,(At The Time Of Booking)',
  `booking_advisor_team_level_percent` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Level Percent Of Advisor Sponsor''s Team At The Time Of Booking',
  `booking_advisor_team_level_percent_diff` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'According to this Commission Will Be Generated',
  `booking_property_plot_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_plot_area_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_built_up_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_built_up_area_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_super_built_up_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_super_built_up_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_plot_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_build_up_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_super_build_up_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discount_amount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discounted_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `fixed_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `govt_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `fixed_rate` tinyint(1) NOT NULL,
  `booking_remark` text COLLATE latin1_general_ci NOT NULL,
  `booking_cancel_status` varchar(10) COLLATE latin1_general_ci NOT NULL COMMENT 'Is Booking Canceled : Yes or NULL',
  `booking_cancel_details` text COLLATE latin1_general_ci NOT NULL COMMENT 'Details Of Cancelled If Canceled Done',
  `booking_payment_mode` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Bank Loan, Self ',
  `booking_payment_mode_bank` varchar(50) COLLATE latin1_general_ci NOT NULL COMMENT 'If Booking By Bank Loan',
  `booking_registry_status` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Registry Done Or Not (Yes, null)',
  `registry_doc` text COLLATE latin1_general_ci NOT NULL,
  `registry_receiver` text COLLATE latin1_general_ci NOT NULL,
  `registry_dispached` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `registry_dispached_by` text COLLATE latin1_general_ci NOT NULL,
  `registry_remarks` text COLLATE latin1_general_ci NOT NULL,
  `registry_date` date NOT NULL,
  `registry_dispached_date` date NOT NULL,
  `booking_mutation_status` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Is Mutation Done (Yes,Null)',
  `approved` tinyint(1) NOT NULL,
  `next_payment_date` date NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property_booking`
--

LOCK TABLES `tbl_property_booking` WRITE;
/*!40000 ALTER TABLE `tbl_property_booking` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property_booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property_booking_cancelled`
--

DROP TABLE IF EXISTS `tbl_property_booking_cancelled`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property_booking_cancelled` (
  `cancel_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_type` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Temporarily/Token or Permanent with Down Payment',
  `booking_commission_status` int(1) NOT NULL,
  `booking_particular` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `booking_voucher_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `booking_date` date NOT NULL,
  `booking_token_exp_date` date NOT NULL COMMENT 'If Temporarily Booked By Token',
  `booking_project_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_project',
  `booking_property_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_property',
  `booking_order_no` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Booking Auto Number',
  `booking_customer_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_customer',
  `booking_executive_type` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Advisor Or Sales Executive',
  `booking_advisor_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_advisor',
  `booking_advisor_level` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_advisor_level_percent` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_advisor_team_level_percent` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_advisor_team_level_percent_diff` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_advisor_team` text COLLATE latin1_general_ci NOT NULL COMMENT 'Array of Sponsors Sepatated by , (At The Time Of Booking)',
  `booking_advisor_team_level` text COLLATE latin1_general_ci NOT NULL COMMENT 'Array of Sponsors Level Sepatated by ,(At The Time Of Booking)',
  `booking_property_plot_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_plot_area_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_built_up_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_built_up_area_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_super_built_up_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_super_built_up_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_plot_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_build_up_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_super_build_up_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discount_amount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discounted_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `fixed_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `govt_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `fixed_rate` tinyint(1) NOT NULL,
  `booking_remark` text COLLATE latin1_general_ci NOT NULL,
  `booking_cancel_status` varchar(10) COLLATE latin1_general_ci NOT NULL COMMENT 'Is Booking Canceled : Yes or NULL',
  `booking_cancel_details` text COLLATE latin1_general_ci NOT NULL COMMENT 'Details Of Cancelled If Canceled Done',
  `booking_payment_mode` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Bank Loan, Self ',
  `booking_payment_mode_bank` varchar(50) COLLATE latin1_general_ci NOT NULL COMMENT 'If Booking By Bank Loan',
  `booking_registry_status` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Registry Done Or Not (Yes, null)',
  `registry_doc` text COLLATE latin1_general_ci NOT NULL,
  `registry_receiver` text COLLATE latin1_general_ci NOT NULL,
  `registry_dispached` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `registry_dispached_by` text COLLATE latin1_general_ci NOT NULL,
  `registry_remarks` text COLLATE latin1_general_ci NOT NULL,
  `registry_date` date NOT NULL,
  `registry_dispached_date` date NOT NULL,
  `booking_mutation_status` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Is Mutation Done (Yes,Null)',
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`cancel_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property_booking_cancelled`
--

LOCK TABLES `tbl_property_booking_cancelled` WRITE;
/*!40000 ALTER TABLE `tbl_property_booking_cancelled` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property_booking_cancelled` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property_booking_deleted`
--

DROP TABLE IF EXISTS `tbl_property_booking_deleted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property_booking_deleted` (
  `deleted_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_type` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Temporarily/Token or Permanent with Down Payment',
  `booking_commission_status` int(1) NOT NULL,
  `booking_particular` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `booking_voucher_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `booking_date` date NOT NULL,
  `booking_token_exp_date` date NOT NULL COMMENT 'If Temporarily Booked By Token',
  `booking_project_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_project',
  `booking_property_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_property',
  `booking_order_no` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Booking Auto Number',
  `booking_customer_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_customer',
  `booking_executive_type` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Advisor Or Sales Executive',
  `booking_advisor_id` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Primary Key Of tbl_advisor',
  `booking_advisor_level` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_advisor_level_percent` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_advisor_team` text COLLATE latin1_general_ci NOT NULL COMMENT 'Array of Sponsors Sepatated by , (At The Time Of Booking)',
  `booking_advisor_team_level` text COLLATE latin1_general_ci NOT NULL COMMENT 'Array of Sponsors Level Sepatated by ,(At The Time Of Booking)',
  `booking_advisor_team_level_percent` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_advisor_team_level_percent_diff` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_plot_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_plot_area_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_built_up_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_built_up_area_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_super_built_up_area` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_super_built_up_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_plot_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_build_up_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_super_build_up_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_construction_price` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discount_amount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `booking_property_discounted_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `fixed_mrp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `govt_rate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `fixed_rate` tinyint(1) NOT NULL,
  `booking_total_payment_received` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'Sum of All Payment Received in this booking',
  `booking_remark` text COLLATE latin1_general_ci NOT NULL,
  `booking_cancel_status` varchar(10) COLLATE latin1_general_ci NOT NULL COMMENT 'Is Booking Canceled : Yes or NULL',
  `booking_cancel_details` text COLLATE latin1_general_ci NOT NULL COMMENT 'Details Of Cancelled If Canceled Done',
  `booking_payment_mode` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Bank Loan, Self ',
  `booking_payment_mode_bank` varchar(50) COLLATE latin1_general_ci NOT NULL COMMENT 'If Booking By Bank Loan',
  `booking_registry_status` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Registry Done Or Not (Yes, null)',
  `registry_doc` text COLLATE latin1_general_ci NOT NULL,
  `registry_receiver` text COLLATE latin1_general_ci NOT NULL,
  `registry_dispached` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `registry_dispached_by` text COLLATE latin1_general_ci NOT NULL,
  `registry_remarks` text COLLATE latin1_general_ci NOT NULL,
  `registry_date` date NOT NULL,
  `registry_dispached_date` date NOT NULL,
  `booking_mutation_status` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'Is Mutation Done (Yes,Null)',
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  `deleted_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`deleted_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property_booking_deleted`
--

LOCK TABLES `tbl_property_booking_deleted` WRITE;
/*!40000 ALTER TABLE `tbl_property_booking_deleted` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property_booking_deleted` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property_booking_extra_charge`
--

DROP TABLE IF EXISTS `tbl_property_booking_extra_charge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property_booking_extra_charge` (
  `charge_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_id` bigint(20) NOT NULL,
  `charge_particular` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `charge_amount` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `charge_paid` varchar(20) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`charge_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property_booking_extra_charge`
--

LOCK TABLES `tbl_property_booking_extra_charge` WRITE;
/*!40000 ALTER TABLE `tbl_property_booking_extra_charge` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property_booking_extra_charge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property_booking_extra_charge_payment`
--

DROP TABLE IF EXISTS `tbl_property_booking_extra_charge_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property_booking_extra_charge_payment` (
  `payment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `charge_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `voucher_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `payment_amount` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_no` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_bank` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_date` date NOT NULL,
  `payment_notes` text COLLATE latin1_general_ci NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property_booking_extra_charge_payment`
--

LOCK TABLES `tbl_property_booking_extra_charge_payment` WRITE;
/*!40000 ALTER TABLE `tbl_property_booking_extra_charge_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property_booking_extra_charge_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property_booking_payments`
--

DROP TABLE IF EXISTS `tbl_property_booking_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property_booking_payments` (
  `payment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `payment_booking_id` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `payment_order_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `payment_voucher_no` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `payment_heading` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `payment_project_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `payment_property_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `payment_customer_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `payment_installment_no` varchar(22) COLLATE latin1_general_ci NOT NULL,
  `payment_amount` varchar(22) COLLATE latin1_general_ci NOT NULL,
  `payment_date` date NOT NULL,
  `payment_booking_executive_type` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `payment_advisor_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `payment_mode` varchar(25) COLLATE latin1_general_ci NOT NULL COMMENT 'DD, Cheque, Fund Transffer, Cash etc',
  `payment_mode_no` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_bank` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `payment_mode_date` date NOT NULL,
  `payment_remarks` text COLLATE latin1_general_ci NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  `payment_first_payment` varchar(1) COLLATE latin1_general_ci NOT NULL COMMENT 'Payment During Booking (First Payment Or Not If First then 1 else null)',
  `approved` tinyint(1) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property_booking_payments`
--

LOCK TABLES `tbl_property_booking_payments` WRITE;
/*!40000 ALTER TABLE `tbl_property_booking_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property_booking_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property_booking_payments_doc`
--

DROP TABLE IF EXISTS `tbl_property_booking_payments_doc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property_booking_payments_doc` (
  `doc_id` bigint(18) NOT NULL AUTO_INCREMENT,
  `payment_id` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `doc_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `doc` text COLLATE latin1_general_ci NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`doc_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property_booking_payments_doc`
--

LOCK TABLES `tbl_property_booking_payments_doc` WRITE;
/*!40000 ALTER TABLE `tbl_property_booking_payments_doc` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property_booking_payments_doc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_property_updates`
--

DROP TABLE IF EXISTS `tbl_property_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_property_updates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `property_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `image` text NOT NULL,
  `remark` text NOT NULL,
  `created_details` text NOT NULL,
  `edited_details` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_property_updates`
--

LOCK TABLES `tbl_property_updates` WRITE;
/*!40000 ALTER TABLE `tbl_property_updates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_property_updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_setting_advisor_level`
--

DROP TABLE IF EXISTS `tbl_setting_advisor_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_setting_advisor_level` (
  `level_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `level_unit_sale` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `level_active_member` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `level_last_month` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `level_target` varchar(18) COLLATE latin1_general_ci NOT NULL COMMENT 'Taraget To Next Level',
  `created_details` text COLLATE latin1_general_ci NOT NULL COMMENT 'By Which User Created ',
  `edited_details` text COLLATE latin1_general_ci NOT NULL COMMENT 'By Which User Edited',
  PRIMARY KEY (`level_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_setting_advisor_level`
--

LOCK TABLES `tbl_setting_advisor_level` WRITE;
/*!40000 ALTER TABLE `tbl_setting_advisor_level` DISABLE KEYS */;
INSERT INTO `tbl_setting_advisor_level` (`level_id`, `level_name`, `level_unit_sale`, `level_active_member`, `level_last_month`, `level_target`, `created_details`, `edited_details`) VALUES (1,'COMPANY','1000000000','10','','100000000000000000','admin, admin, 2022-03-16, 01:37:24 PM, 110.227.53.118','admin, admin, 2022-03-16, 01:37:24 PM, 110.227.53.118'),(2,'Business Associate','05','1','','10000000','admin, admin, 2022-04-28, 12:12:42 PM, 117.198.18.211','admin, admin, 2022-04-28, 12:12:42 PM, 117.198.18.211'),(3,'Sales Manager','8','1','','15000000','admin, admin, 2022-04-28, 12:13:08 PM, 117.198.18.211','admin, admin, 2022-04-28, 12:13:08 PM, 117.198.18.211'),(4,'Senior Sales Manager','10','1','','20000000','admin, admin, 2022-04-28, 12:01:19 PM, 117.198.18.211','admin, admin, 2022-04-28, 12:01:19 PM, 117.198.18.211'),(5,'Business Development Manager','1000','1','','100000000','admin, admin, 2022-04-28, 12:00:51 PM, 117.198.18.211','admin, admin, 2022-04-28, 12:00:51 PM, 117.198.18.211'),(6,'Senior Business Development Manager','1000','10','','10000','admin, admin, 2022-04-28, 11:59:53 AM, 117.198.18.211','admin, admin, 2022-04-28, 11:59:53 AM, 117.198.18.211'),(7,'Business Collector','100','1','','10000000','admin, admin, 2022-04-28, 11:58:57 AM, 117.198.18.211','admin, admin, 2022-04-28, 11:58:57 AM, 117.198.18.211'),(8,'Senior Business Collector','100','1','','10000000','admin, admin, 2022-04-28, 11:58:17 AM, 117.198.18.211','admin, admin, 2022-04-28, 11:58:17 AM, 117.198.18.211'),(9,'Marketing Head','25','10','','10000000','admin, admin, 2022-04-22, 12:20:47 PM, 117.198.18.179','admin, admin, 2022-04-22, 12:20:47 PM, 117.198.18.179'),(10,'Senior Marketing Head','30','10','','10000000','admin, admin, 2022-04-22, 12:19:36 PM, 117.198.18.179','admin, admin, 2022-04-22, 12:19:36 PM, 117.198.18.179'),(11,'Sales Representative','35','10','','10000000','admin, admin, 2022-04-22, 12:17:45 PM, 117.198.18.179','admin, admin, 2022-04-22, 12:17:45 PM, 117.198.18.179'),(12,'Senior Sales Representative','40','10','','10000000','admin, admin, 2022-04-22, 12:15:15 PM, 117.198.18.179','admin, admin, 2022-04-22, 12:15:15 PM, 117.198.18.179'),(13,'Field Officer','45','10','','10000000','admin, admin, 2022-04-22, 12:14:07 PM, 117.198.18.179','admin, admin, 2022-04-22, 12:14:07 PM, 117.198.18.179'),(14,'Senior Field Officer','50','10','','10000000','admin, admin, 2022-04-22, 12:12:10 PM, 117.198.18.179','admin, admin, 2022-04-22, 12:12:10 PM, 117.198.18.179'),(15,'Marketing Director','60','10','','02','admin, admin, 2022-04-22, 12:08:50 PM, 117.198.18.179','admin, admin, 2022-04-22, 12:08:50 PM, 117.198.18.179'),(16,'Senior Marketing Director','70','10','','02','admin, admin, 2022-04-22, 12:08:01 PM, 117.198.18.179','admin, admin, 2022-04-22, 12:08:01 PM, 117.198.18.179'),(17,'Vice President','80','10','','02','admin, admin, 2022-04-28, 11:57:02 AM, 117.198.18.211','admin, admin, 2022-04-28, 11:57:02 AM, 117.198.18.211'),(18,'Senior Vice President','90','10','','10000000','admin, admin, 2022-04-28, 11:56:42 AM, 117.198.18.211','admin, admin, 2022-04-28, 11:56:42 AM, 117.198.18.211'),(19,'LEVEL-18','10','10','','10000000','admin, admin, 2022-03-16, 02:31:27 PM, 110.227.61.68','admin, admin, 2022-03-16, 02:31:27 PM, 110.227.61.68');
/*!40000 ALTER TABLE `tbl_setting_advisor_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_setting_advisor_level_with_property_type`
--

DROP TABLE IF EXISTS `tbl_setting_advisor_level_with_property_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_setting_advisor_level_with_property_type` (
  `level_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `property_type_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `commission_percent` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `project_id` varchar(20) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_setting_advisor_level_with_property_type`
--

LOCK TABLES `tbl_setting_advisor_level_with_property_type` WRITE;
/*!40000 ALTER TABLE `tbl_setting_advisor_level_with_property_type` DISABLE KEYS */;
INSERT INTO `tbl_setting_advisor_level_with_property_type` (`level_id`, `property_type_id`, `commission_percent`, `project_id`) VALUES ('1','13','100','8'),('1','12','100','8'),('1','8','100','8'),('1','7','100','8'),('1','2','100','8'),('1','1','100','8'),('1','13','100','3'),('1','12','100','3'),('1','8','100','3'),('1','7','100','3'),('1','2','100','3'),('1','1','100','3'),('1','13','100','7'),('1','12','100','7'),('1','8','100','7'),('1','7','100','7'),('1','2','100','7'),('1','1','100','7'),('1','13','100','2'),('1','12','100','2'),('1','8','100','2'),('1','7','100','2'),('1','2','100','2'),('1','1','100','2'),('2','13','2.5','8'),('2','12','2.5','8'),('2','8','2.5','8'),('2','7','2.5','8'),('2','1','5','8'),('2','2','2.5','8'),('3','13','2.75','8'),('3','12','2.75','8'),('3','8','2.75','8'),('3','7','2.75','8'),('3','1','5.5','8'),('3','2','2.75','8'),('4','13','3','8'),('4','12','3','8'),('4','8','3','8'),('4','7','3','8'),('4','2','3','8'),('4','1','6','8'),('5','13','3.25','8'),('5','12','3.25','8'),('5','8','3.25','8'),('5','7','3.25','8'),('5','2','3.25','8'),('5','1','6.5','8'),('6','13','3.5','8'),('6','12','3.5','8'),('6','8','3.5','8'),('6','7','3.5','8'),('6','2','3.5','8'),('6','1','7','8'),('7','13','3.75','8'),('7','12','3.75','8'),('7','8','3.75','8'),('7','7','3.75','8'),('7','2','3.75','8'),('7','1','7.5','8'),('8','13','4','8'),('8','12','4','8'),('8','8','4','8'),('8','7','4','8'),('8','2','4','8'),('8','1','8','8'),('9','13','4.25','8'),('9','12','4.25','8'),('9','8','4.25','8'),('9','7','4.25','8'),('9','2','4.25','8'),('9','1','8.5','8'),('10','13','4.5','8'),('10','12','4.5','8'),('10','8','4.5','8'),('10','7','4.5','8'),('10','2','4.5','8'),('10','1','9','8'),('11','13','4.75','8'),('11','12','4.75','8'),('11','8','4.75','8'),('11','7','4.75','8'),('11','2','4.75','8'),('11','1','9.5','8'),('12','13','5','8'),('12','12','5','8'),('12','8','5','8'),('12','7','5','8'),('12','2','5','8'),('12','1','10','8'),('13','13','5.25','8'),('13','12','5.25','8'),('13','8','5.25','8'),('13','7','5.25','8'),('13','2','5.25','8'),('13','1','10.5','8'),('14','13','5.5','8'),('14','12','5.5','8'),('14','8','5.5','8'),('14','7','5.5','8'),('14','2','5.5','8'),('14','1','11','8'),('15','13','5.75','8'),('15','12','5.75','8'),('15','8','5.75','8'),('15','7','5.75','8'),('15','2','5.75','8'),('15','1','11.5','8'),('16','13','6','8'),('16','12','6','8'),('16','8','6','8'),('16','7','6','8'),('16','2','6','8'),('16','1','12','8'),('17','13','6.25','8'),('17','12','6.25','8'),('17','8','6.25','8'),('17','7','6.25','8'),('17','2','6.25','8'),('17','1','12.5','8'),('18','13','6.5','8'),('18','12','6.5','8'),('18','8','6.5','8'),('18','7','6.5','8'),('18','2','6.5','8'),('18','1','13','8'),('19','13','7.5','8'),('19','12','7.5','8'),('19','8','7.5','8'),('19','7','7.5','8'),('19','2','7.5','8'),('19','1','15','8'),('19','13','0','3'),('19','12','0','3'),('19','8','0','3'),('19','7','0','3'),('19','2','0','3'),('19','1','0','3'),('19','13','0','7'),('19','12','0','7'),('19','8','0','7'),('19','7','0','7'),('19','2','0','7'),('19','1','0','7'),('19','13','0','2'),('19','12','0','2'),('19','8','0','2'),('19','7','0','2'),('19','2','0','2'),('19','1','15','2');
/*!40000 ALTER TABLE `tbl_setting_advisor_level_with_property_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_setting_property_type`
--

DROP TABLE IF EXISTS `tbl_setting_property_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_setting_property_type` (
  `property_type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `property_type` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`property_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_setting_property_type`
--

LOCK TABLES `tbl_setting_property_type` WRITE;
/*!40000 ALTER TABLE `tbl_setting_property_type` DISABLE KEYS */;
INSERT INTO `tbl_setting_property_type` (`property_type_id`, `property_type`, `created_details`, `edited_details`) VALUES (1,'PLOTS','admin, admin, 2017-07-22, 04:12:27 PM, 47.247.8.175','admin, admin, 2017-07-22, 04:12:27 PM, 47.247.8.175'),(2,'FLAT','admin, admin, 2014-04-17, 11:03:41 AM, 122.168.189.38','admin, admin, 2014-04-17, 11:03:41 AM, 122.168.189.38'),(7,'HOUSE','admin, admin, 2016-09-18, 06:47:48 PM, 110.224.219.65','admin, admin, 2016-09-18, 06:47:48 PM, 110.224.219.65'),(8,'BANGLOW','admin, admin, 2020-01-02, 05:50:53 PM, 171.61.60.121','admin, admin, 2020-01-02, 05:50:53 PM, 171.61.60.121'),(12,'FARM HOUSE','admin, admin, 2020-01-02, 05:52:41 PM, 171.61.60.121','admin, admin, 2020-01-02, 05:52:41 PM, 171.61.60.121'),(13,'SHOPS','admin, admin, 2020-02-27, 11:51:59 AM, 171.60.160.212','admin, admin, 2020-02-27, 11:51:59 AM, 171.60.160.212');
/*!40000 ALTER TABLE `tbl_setting_property_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_setting_tds`
--

DROP TABLE IF EXISTS `tbl_setting_tds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_setting_tds` (
  `tds` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `created_details` text COLLATE latin1_general_ci NOT NULL,
  `edited_details` text COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_setting_tds`
--

LOCK TABLES `tbl_setting_tds` WRITE;
/*!40000 ALTER TABLE `tbl_setting_tds` DISABLE KEYS */;
INSERT INTO `tbl_setting_tds` (`tds`, `created_details`, `edited_details`) VALUES ('10','admin, admin, 2020-01-02, 11:50:04 AM, 171.61.60.121','admin, admin, 2020-01-02, 11:50:04 AM, 171.61.60.121');
/*!40000 ALTER TABLE `tbl_setting_tds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_site_settings`
--

DROP TABLE IF EXISTS `tbl_site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_site_settings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_name` text COLLATE latin1_general_ci NOT NULL COMMENT 'Used in Titel Tag',
  `site_heading` text COLLATE latin1_general_ci NOT NULL COMMENT 'Used In Header And Menu',
  `site_icon` text COLLATE latin1_general_ci NOT NULL COMMENT 'Used In Real Icon',
  `site_logo` text COLLATE latin1_general_ci NOT NULL COMMENT 'Used In Header As Heading Logo',
  `site_url_home` text COLLATE latin1_general_ci NOT NULL COMMENT 'Main Site Url',
  `site_application_url` text COLLATE latin1_general_ci NOT NULL COMMENT 'Application In Site Url',
  `site_company_name` text COLLATE latin1_general_ci NOT NULL COMMENT 'Full Name Of Company',
  `site_iso` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `site_copyright` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `advisor_title` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `id_prefix` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `email` text COLLATE latin1_general_ci NOT NULL,
  `phone` text COLLATE latin1_general_ci NOT NULL,
  `mobile` text COLLATE latin1_general_ci NOT NULL,
  `address` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_site_settings`
--

LOCK TABLES `tbl_site_settings` WRITE;
/*!40000 ALTER TABLE `tbl_site_settings` DISABLE KEYS */;
INSERT INTO `tbl_site_settings` (`id`, `site_name`, `site_heading`, `site_icon`, `site_logo`, `site_url_home`, `site_application_url`, `site_company_name`, `site_iso`, `site_copyright`, `advisor_title`, `id_prefix`, `email`, `phone`, `mobile`, `address`) VALUES (12,'DCT | Real Estate Developers','DCT | Real Estate Developers','','','https://dctrealestate.spitechcloud.in/','https://dctrealestate.spitechcloud.in/Application/','DCT | Real Estate Developers','','','Advisor','DCT','companydct242@gmail.com','','+91-7223095090,7270886613','Behind High Court,Chhatauna Road,Indu Imperia,Bilaspur, Chhattisgarh-495001');
/*!40000 ALTER TABLE `tbl_site_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_sms_sent`
--

DROP TABLE IF EXISTS `tbl_sms_sent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sms_sent` (
  `sms_id` int(10) NOT NULL AUTO_INCREMENT,
  `sms_birthday` date NOT NULL,
  `sms_anniversary` date NOT NULL,
  `sms_token_expiry_pre` date NOT NULL,
  `sms_token_expiry_current` date NOT NULL,
  `sms_token_expiry_after` date NOT NULL,
  PRIMARY KEY (`sms_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_sms_sent`
--

LOCK TABLES `tbl_sms_sent` WRITE;
/*!40000 ALTER TABLE `tbl_sms_sent` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_sms_sent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_spitech_sms_server`
--

DROP TABLE IF EXISTS `tbl_spitech_sms_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_spitech_sms_server` (
  `sms` tinyint(1) NOT NULL,
  `sms_url` text COLLATE latin1_general_ci NOT NULL,
  `mobile_parameter` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `message_parameter` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `mobile_prefix` varchar(5) COLLATE latin1_general_ci NOT NULL,
  `parameter1` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `value1` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `parameter2` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `value2` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `parameter3` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `value3` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `parameter4` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `value4` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `parameter5` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `value5` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `balance_url` text COLLATE latin1_general_ci NOT NULL,
  `bparameter1` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `bvalue1` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `bparameter2` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `bvalue2` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `bparameter3` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `bvalue3` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `bparameter4` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `bvalue4` varchar(25) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_spitech_sms_server`
--

LOCK TABLES `tbl_spitech_sms_server` WRITE;
/*!40000 ALTER TABLE `tbl_spitech_sms_server` DISABLE KEYS */;
INSERT INTO `tbl_spitech_sms_server` (`sms`, `sms_url`, `mobile_parameter`, `message_parameter`, `mobile_prefix`, `parameter1`, `value1`, `parameter2`, `value2`, `parameter3`, `value3`, `parameter4`, `value4`, `parameter5`, `value5`, `balance_url`, `bparameter1`, `bvalue1`, `bparameter2`, `bvalue2`, `bparameter3`, `bvalue3`, `bparameter4`, `bvalue4`) VALUES (1,'http://sendsms.spitechwebservices.com/api/sendmsg.php','phone','text','','user','SIDDHIBUILD','pass','SIDDHIBUILD','sender','SIDDHI','priority','ndnd','stype','normal','','','','','','','','','');
/*!40000 ALTER TABLE `tbl_spitech_sms_server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_spitech_user`
--

DROP TABLE IF EXISTS `tbl_spitech_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_spitech_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `user_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `user_password` text COLLATE latin1_general_ci NOT NULL,
  `user_email_id` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `user_mobile` varchar(10) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_spitech_user`
--

LOCK TABLES `tbl_spitech_user` WRITE;
/*!40000 ALTER TABLE `tbl_spitech_user` DISABLE KEYS */;
INSERT INTO `tbl_spitech_user` (`id`, `user_id`, `user_name`, `user_password`, `user_email_id`, `user_mobile`) VALUES (1,'admin','Spitech Pvt Ltd.','e6e061838856bf47e1de730719fb2609','admin@spitech.co.in','7828796979');
/*!40000 ALTER TABLE `tbl_spitech_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'spite7n9_dctrealestate'
--

--
-- Dumping routines for database 'spite7n9_dctrealestate'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-25 15:39:21
